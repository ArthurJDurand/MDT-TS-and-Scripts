/*******************************************************************************
///<copyright>
///   Copyright� 2014 Condusiv Technologies Corporation, All Rights Reserved.
///</copyright>
///
///<file>Header.js</file>
///
///<module>Header for Header.html</module>
///
///<summary>
///  Functions for rendering and handling Header.html display
///</summary>
///
///<revision>
///    02/24/2014 - Cindy Wang -- Changed name "CMC" to "CMC"
///    02/24/2014 - Cindy Wang -- Update about box
///    02/25/2014 - Cindy Wang -- Removed license check for displaying DymaxIO VM
///								  and DymaxIO Server on the header.
///    03/11/2014 - Cindy Wang -- Get root_path from the response of
///                               getInstalledProducts request
///    10/06/2015 � Dinsey Basil - UI for stand alone product
///</revision>
///
*******************************************************************************/

var Header = function() {
	var _self = this;
	var hasProductUpdate = false;
	var _systemManagers;

	var getProductInfo = function (key, url) {
	    var product_url = window.PRDUIBASEPATH + url + 'ProductInfo.json';
		var info = {};
		$.ajax({
			url:  product_url,
			contentType: "application/json",
		 	dataType: 'json',
		    success: function( data ) {
				info = data;
			},
			error: function() {
				console.log("No product info for: " + key );
			},
			async: false
		});
		return info;
	};

	getMachineInfo = function (url) {
	    var product_url = window.PRDUIBASEPATH + url + 'Requests/getMachineInfo.json';
	    $.ajax({
	        url: product_url,
	        contentType: "application/json",
	        dataType: 'json',
	        type: "POST",
	        success: function (data) {
	            if (data.type !== undefined && data.type != null)
	                sessionStorage.setItem(cmcApp.MACHINE_SESSION.TYPE, data.type);
	            if (data.productversion !== undefined && data.productversion != null)
	                sessionStorage.setItem(cmcApp.MACHINE_SESSION.VERSION, data.productversion);
	        },
	        error: function (xhr, textStatus, errorThrown) {
	            console.log("[" + product_url + "] " + errorThrown);
	        }
	    });
	};

	var getSystemData = function () {

	    function errorGetSystemsData(xhr, textStatus, errorThrown) {
	        console.log("error getting systems data: " + errorThrown);
	    }
	    var systems = {};
	    $.ajax({
	        url: '/Vlocity/Requests/getSystemsData.json',
	        contentType: "application/json",
	        dataType: 'json',
	       // data: JSON.stringify(request_info),
	        success: function( data ) {
	            systems = data['systems'];
	        },
	        error: errorGetSystemsData,
	        async: false
	    });
	    return systems;
	};
	var getProductLicenseState = function () {

	    function errorGetProductLicenseState(xhr, textStatus, errorThrown) {
	        console.log("error getting license data: " + errorThrown);
	    }
	    var licenses = {};
	    var expState = '';

	    $.ajax({
	        url: '/Vlocity/Requests/getLicenseSummary.json',
	        contentType: "application/json",
	        dataType: 'json',
	        // data: JSON.stringify(request_info),
	        success: function (data) {
	            expState = data['state'];
//	window.local = "/Vlocity/License/LicenseManagement.html";
//	            expState = licenses['state'];
//	            expState = licenses[0]['state'];
	        },
	        error: errorGetProductLicenseState,
	        async: false
	    });
	    return expState;
	};


	var hasSystemManager = function () {

	  var existSystemManager = false;

		$.ajax({
		  url: '/Vlocity/Requests/getSystemManagers.json',
			contentType: "application/json",
		 	dataType: 'json',
		  success: handleGetSystemManagers,
		  error: errorGetSystemManagers,
			async: false
		});

		function errorGetSystemManagers(xhr, textStatus, errorThrown) {
			console.log("[getLicenseSummary.json] " + errorThrown);
	    }

		function handleGetSystemManagers(data) {
		  _systemManagers = data['SystemManagers'];
		  existSystemManager = _systemManagers.length > 0;
		}

		return existSystemManager;
	}

	var updateAccountMenu = function () {

	  var masterConfig = new MasterConfig();

	  $(masterConfig).bind(MasterConfig.GET_BROWSER_TIMEOUT_COMPLETE, function f1(event, data) {

	    $(masterConfig).unbind(MasterConfig.GET_BROWSER_TIMEOUT_COMPLETE, f1);

	    if (data["timeout"] == 0) {
	      $('.accountMenu').remove();
	    } else {

	    }

	  });

	  masterConfig.getBrowserTimeout();
	}

	var getInstalledProductsFromService = function() {

		var installed_products = {};
		$.ajax({
			url: '/Vlocity/Requests/getInstalledProducts.json',
			contentType: "application/json",
		 	dataType: 'json',
		    success: handleInstalledProducts,
			error:  errorInstalledProducts,
			async: false
		});

		function handleInstalledProducts(response) {
		    var data = response.prods;
		    var cmc_version = "",
            cmc_patch = "",
            root_path = "",
            product_name="";
		    product_table = {};

		    if (response['root_path'])
		        root_path = response['root_path'];
		    else
		        root_path = cmcApp.Map.LicensePath;

		    for (var i = 0; i < data.length; i++) {

		        //if (data[i].key == 'VlocityServer') continue;

		        //// TODO: Don't map this to different keys and deal with the fallout throughout
		        //// the UI.
		        ////
		        //// The real service is returning keys like "VlocityVM". The UI expects
		        //// "VlocityVM". The following is a temporary fix. There are places where I use
		        //// these keys as part of generated html as substrings of the ids on html elements
		        //// and other sorts of generated mark-up. I think the hyphens would be okay in all
		        //// cases but am not positive. Also there are places in code that is common between
		        //// DymaxIO VM and DymaxIO Server where these keys are tested directly that would
		        //// need to be changed.


		        var map_keys = {
					"V-locityVM": "DymaxIO",
					"V-locityServer": "DymaxIO",
					"VlocityVM": "DymaxIO",
					"VlocityServer": "DymaxIO"
		        };

		        if (map_keys.hasOwnProperty(data[i].key)) {
		            data[i].key = map_keys[data[i].key];
		        }

		        if (data[i].key == window.VMKEY) {
		            cmcApp.Help.product.setVM(data[i].key, data[i].name);
		        }

		        cmcApp.Help.product.setCurProduct(data[i].key, data[i].name);

		        product_table[data[i].key] = data[i];

		        // get the extra product info on a per-product basis...
		        var info = getProductInfo(data[i].key, data[i].url);
		        product_table[data[i].key].info = info;

		        //get machine info
		        getMachineInfo(data[i].url);
		    }


		    installed_products = new function() {

		        this.getCmcVersion = function() {
		            return cmc_version;
		        }

		        this.getCmcInternalVersion = function() {
		            return response.cmc_version;
		        }

		        this.getProductByKey = function(key) {
		            return product_table[key];
		        }

		        this.hasProduct = function(key) {
		            return product_table.hasOwnProperty(key);
		        }

		        this.getNthProduct = function(n) {
		            return product_table[Object.keys(product_table)[n]];
		        }

		        this.getNumProducts = function() {
		            return Object.keys(product_table).length;
		        }

		        this.getProductKeys = function() {
		            return Object.keys(product_table);
		        }

		        this.getNthProductKey = function(n) {
		            return Object.keys(product_table)[n];
		        }

		        this.getRootPath = function() {
		            return root_path;
		        }

		        this.getCmcPatch = function () {
		            return cmc_patch;
		        }
		    }
		}

		function errorInstalledProducts (xhr, textStatus, errorThrown) {
			console.log("[getInstalledProducts.json] " + errorThrown);
	    }

		return installed_products;
	}

	var showAboutCmcBox = function (e, products) {

	  function generateAboutBoxContent() {

	    var vmcVersion = products.getCmcVersion(),
	        vmcPatch = products.getCmcPatch();

	    if (vmcVersion == '' && sessionStorage.getItem(cmcApp.MACHINE_SESSION.VERSION) != null)
	        vmcVersion = sessionStorage.getItem(cmcApp.MACHINE_SESSION.VERSION);

		  var content = "\
				<div style='padding:20px 20px 20px 20px'>\
        <div tabindex='29003'>\
					<p><h4>DymaxIO</h4></p>\
					<p><h4>Version: " + vmcVersion + " &nbsp;&nbsp;&nbsp;&nbsp;" + (vmcPatch ? "(" + vmcPatch + ")" : "") + "</h4></p><BR>";
			/*
			for (var i = 0; i < products.getNumProducts(); i++) {
				var prod = products.getNthProduct(i);
				content +=
					"<p><h4>" + prod.name + "</h4></p>" +
					"<p><h4>Version: " + prod.version + " &nbsp;&nbsp;&nbsp;&nbsp;" +
          (prod.patchLevel ? "(" + prod.patchLevel + ")" : "") +
					"</h4></p><br/>"
			}
			*/
			if (hasProductUpdate == true) {
			  content += "<p><a tabindex='29004' id='openPatchLink'>View product update status.</a></p>";
			}
			content += "</div>";

			content += "<br/>";
			content += "\
				<p ><a tabindex='29005' href='http://www.condusiv.com'>www.condusiv.com</a></p>\
				<br/>\
				<p ><h4 tabindex='29006'>&copy; 2022 Condusiv Technologies. All Rights reserved.</h4></p>\
				</div>"

			return content;
		}

		var about_box = new Popup(
			"AboutCmcBox",
			"ABOUT",
			generateAboutBoxContent(),
			{width: 420, has_cancel_button: false},
      false
		);
		about_box.doModal(  );
	}

	var hookUpMenuLinks = function( products ) {
		$('#AboutCmcLink').on('click keydown',
			function (e) {
			  if (e.type == 'click' || e.which == 13) {
			    e.preventDefault();
			    showAboutCmcBox(e, products);
			    return false;
			  }
			}
		);
		$('#ManageNotiSettingsLink').on('click keydown',
			function (e) {
			  if (e.type == 'click' || e.which == 13) {
			    if ($(this).hasClass('disabled-link'))
			      e.preventDefault();
			    else
			      cmcApp.Lib.CommunicationSetting.showModal(
            e   // event object
                  );
			  }
			}
		);
		$('body').on('click keydown',' #openPatchLink',
      function (e) {
        if (e.type == 'click' || e.which == 13) {
          $('#overlay').remove();
          cmcApp.Lib.UIComponent.openModal(e, '/Vlocity/ReleaseModal.html', 'content', function () {
            $('.closeModal').click(function () { $('#overlay').remove(); });
          });

        }
      }
    );
	}

	var accountMenuHandler = function () {

	  var user = sessionStorage.getItem(cmcApp.CURRENT_USER_IN_SESSION);

	  var account = new Account();

	  if (user !== undefined && user != null && user != "") {
	    account.setCurrUser(user);
	  }

	  $('#logoutLink').on('click keydown', function ($e) {
	    if ($e.type == 'click' || $e.which == 13) {
	      sessionStorage.removeItem(cmcApp.CURRENT_USER_IN_SESSION)
	      account.signout();
	    }
	  });

	  $('#accountInfoLink').on('click keydown', function ($e) {
	    if ($e.type == 'click' || $e.which == 13) {
	      account.openAccountInfoModal();
	    }
	  });
	}

	var generateHeader = function( prod_key, products, create_subheader, /*subheader_data,*/ help_tag, product_forThisPageHelp ) {
		var header_div = $('#CmcHeader');

		$.ajax({
		  url: '/Vlocity/Common/Header.html',
		  contentType: "text/html",
		  dataType: 'html',
		  success: loadHeader,
		  error: function (xhr, textStatus, errorThrown) {
		    console.error(textStatus + " message: " + errorThrown + " responseText: " + xhr.responseText);
		  },
		  async: false,
		  type: "POST"
		});

		function loadHeader(data, textStatus, XMLHttpRequest) {

		  header_div.html(data);

		  var tabindexOffset = cmcApp.HEADER_FIRST_TAB_INDEX + 34;

		  if (products.hasProduct(prod_key)) {
		    $('#' + prod_key + '_Tab').attr("class", "active");
		  } else {
		    if ($('#myEnvironment').length > 0 || $('#systemDetailPage').length > 0) {
		      $('#CMC_MyEnvironment').attr("class", "active");
		    } else {
		      $('#V_Main').attr("class", "active");
		    }
		  }

		  if (create_subheader) {
		    create_subheader(prod_key /*, subheader_data*/);
		  }
		  hookUpMenuLinks(products);
		  accountMenuHandler();

		  //if (hasLegacySystemManager) {
		  ////  var admin_link_menu = $('#AdminMenuLinksDropdown');

		  ////  admin_link_menu.append(
          ////'<li><a href="#" class="uninstallSysMar dropdown-option" >Uninstall Legacy System Managers</a></li>');

		  //  $('.uninstallSysMar').click(function ($e) {

		  //    sessionStorage.setItem(cmcApp.JOB_SESSION.CURRENT_MODE, cmcApp.JOB_SESSION.MODE.CREATE);
		  //    sessionStorage.setItem(cmcApp.JOB_SESSION.INITIATIVE_PAGE, window.location.pathname);
		  //    sessionStorage.setItem(cmcApp.JOB_SESSION.CURRENT_JOB_TYPE, cmcApp.JOB_SESSION.JOB_TYPE.UNINSTALL_SYSTEM_MAMANGERS);
		  //    sessionStorage.setItem(cmcApp.JOB_SESSION.SELECTED_SYSTEMS, JSON.stringify(_systemManagers));
		  //    window.location = '/Vlocity/Job/jobDetails.html';
		  //  });

		  //}
		  //Add the per-product QuickLinks menu
		  var quick_links_menu = $('#QuickLinksDropdown');

		  if (quick_links_menu.length) {

		    for (var i = 0; i < products.getNumProducts() ; i++) {
		      var prod = products.getNthProduct(i);

		      var config_url = window.PRDUIBASEPATH + prod.url + 'Configuration.html'; //TODO REMOVE
		      var reports_url = window.PRDUIBASEPATH + prod.url + 'FullReports.html'; //TODO REMOVE

		      $('.manageConfigPolicyLink').attr('href', config_url);
		      $('.manageReportsLink').attr('href', reports_url);

		    }
		  }

		  //Add help link for this screen
		  if (help_tag) {
		    if (product_forThisPageHelp && product_forThisPageHelp != "")
		      setHelpForThisPage(product_forThisPageHelp, help_tag);
		    else
		      setHelpForThisPage(prod_key, help_tag);
		  }

		  $('body').trigger(Header.HEADER_INITIALIZED);

		  cmcApp.Lib.UIComponent.addKeyboardActionToTopMenu('#accountExtends');
		  cmcApp.Lib.UIComponent.addKeyboardActionToTopMenu('#adminExtends');
		  cmcApp.Lib.UIComponent.addKeyboardActionToTopMenu('#helpExtends');

		  cmcApp.Lib.UIComponent.addKeyboardActionToDropdown('#quickLinks');

		  updateAccountMenu();

		}
	};

	var setHelpForThisPage = function( prod_key, tag ) {
	    var help_url = "/Vlocity/Help/DymaxIO_Help_CSH.htm";
    /*
		if (prod_key == "CMC") {
			help_url = "/Vlocity/Help/DymaxIO_Help_CSH.htm"
		} else {
			var prod = Header.getInstalledProducts().getProductByKey(prod_key);
			help_url = (prod.info && prod.info.HelpUrl) ?
				'/UI' + prod.url + 'Help/' + prod.info.HelpUrl: //TODO REMOVE '/Vlocity/UI/VM/'
				"";
		}
    */
		if (help_url) {
			help_url = help_url + "#" + tag;
		} else {
			help_url = "#";
		}

		$("#HelpForThisScreenLink").click(function ($e) {

		  $('[TabIndex="1"]').focus();

		  window.open(help_url, '_blank', 'location=yes,resizable=yes');

		});

		$("#CmcHelpLink").click(function ($e) {

		  $('[TabIndex="1"]').focus();

		  window.open('/Vlocity/Help/DymaxIO_Help_CSH.htm', '_blank', 'location=yes,resizable=yes');

		});

	}

	var getInstalledProducts = function() {
		return products;
	}

	var products = getInstalledProductsFromService();
    //var hasLegacySystemManager = hasSystemManager();

	var initialize = function (prod_key, create_subheader_callback, help_tag, product_forThisPageHelp) {
	    if (null == prod_key || '' == prod_key) {
	        cmcApp.ProductInfo.getProductInfo();
	        prod_key = window.PRODUCTKEY;
	    }
	  generateHeader(prod_key, products, create_subheader_callback, help_tag, product_forThisPageHelp);

	  $.post('/Vlocity/patch.html', function (data) {
	    hasProductUpdate = $.trim(data) != "";
	  });

	  //$.getScript('/Vlocity/Common/Account.js', function (data, textStatus, obj) {

	  //});
    /*
	  $('body').on('focusin', '#adminExtends', function ($e) {

	    $('#adminExtends > ul').addClass('extendsHover').show();
	    $('#adminExtends > ul > li > a').addClass('extendsLiAHover').show();

	  });

	  $('body').on('focusout', '#adminExtends', function ($e) {
	    //$('#adminExtends > ul').removeClass('extendsHover').hide();
	    //$('#adminExtends > ul > li > a').removeClass('extendsLiAHover').hide();
	  });

	  $('body').on('keydown', '#adminExtends',  function (e) {
	    if (e.which == 40) { // down
	      e.preventDefault();
	      $(this).find('.extendsLiAHover:first').focus();
	      return false;
	    }
	  });

	  $('body').on('keydown', '#adminExtends .extendsLiAHover', function (e) {

	    if (e.which == 40) { // down
	      e.preventDefault();
	      var $nextChild = $(this).parent().next();
	      var $nextOption = $nextChild.find(".extendsLiAHover");
	      while ($nextOption.length == 0 && $nextChild.length == 1) {
	        $nextOption = $nextChild.find(".extendsLiAHover");
	        $nextChild = $nextChild.next();
	        console.log('$nextOption.length = ' + $nextOption.length + ' $nextChild.length = ' + $nextChild.length);
	      }
	      $nextOption.focus();
	      return false; // stops the page from scrolling
	    }
	    if (e.which == 38) { // up
	      e.preventDefault();
	      var $prevChild = $(this).parent().prev();
	      var $prevOption = $prevChild.find(".extendsLiAHover");
	      while ($prevOption.length == 0 && $prevChild.length == 1) {
	        $prevOption = $prevChild.find(".extendsLiAHover");
	        $prevChild = $prevChild.prev();
	        console.log('$prevOption.length = ' + $prevOption.length + ' $prevChild.length = ' + $prevChild.length);
	      }
	      $prevOption.focus();
	      return false; // stops the page from scrolling
	    }
	    if (e.which == 13) { // enter

	    }
	    if (e.which == 9) { // tab
	      e.preventDefault();
	      $('#adminExtends > ul').removeClass('extendsHover').hide();
	      $('#adminExtends > ul > li > a').removeClass('extendsLiAHover').hide();

	      var currentTabindex =Number( $('#adminExtends').attr('tabindex'));
	      var $currentTarget, found = false;

	      var tabIndexedElements = $('*[tabindex]').each(function (e) {
	        $currentTarget = $(this);
	        if (found == true && $currentTarget.prop('disabled') == false) {
	          $currentTarget.focus();
	          $dropdownTarget.removeClass('open');
	          return false;
	        }
	        var targetTabIndex = Number($currentTarget.attr('tabindex'));

	        if (currentTabindex == targetTabIndex) {
	          found = true;
	        }
	      });

	      return false;
	    }
	  });
	  */
	};

	var initProductUpdate = function () {

	  $.post('/Vlocity/patch.html', function (data) {
	    var productUpdateList = [];
	    var updateDate = "";

	    var strDelimiter = ",";

	    var objPattern = new RegExp(
      (
          "(\\" + strDelimiter + "|\\r?\\n|\\r|^)" +
          "(?:\"([^\"]*(?:\"\"[^\"]*)*)\"|" +
          "([^\"\\" + strDelimiter + "\\r\\n]*))"
      ),
      "gi"
      );
	    var arrData = [[]];

	    var arrMatches = null;
	    while (arrMatches = objPattern.exec(data)) {

	      var strMatchedDelimiter = arrMatches[1];
	      if (
            strMatchedDelimiter.length &&
            strMatchedDelimiter !== strDelimiter
            ) {
	        arrData.push([]);

	      }

	      var strMatchedValue;

	      if (arrMatches[2]) {
	        strMatchedValue = arrMatches[2].replace(
              new RegExp("\"\"", "g"),
              "\""
              );
	      } else {
	        strMatchedValue = arrMatches[3];
	      }
	      arrData[arrData.length - 1].push(strMatchedValue);
	    }

	    if (arrData.length > 0 && arrData[0].length > 0) {
	      updateDate = arrData[0][0];
	      $('#updateDate').html(updateDate);
	    }
	    if (arrData.length > 1) {
	      var updateProductObj = {};
	      for (var i = 1; i < arrData.length; i++) {

	        if (arrData[i].length == 2) {
	          updateProductObj = {};
	          updateProductObj.systemName = arrData[i][0];
	          updateProductObj.update = arrData[i][1];
	          productUpdateList.push(updateProductObj);
	        }
	      }
	    }


	    var sortHead;
	    var sortObj;

	    if (productUpdateList != null && productUpdateList.length > 0) {
	      sortHead = "#productUpdateTable > thead";
	      sortObj = {
	        0: "systemName",
	        1: "update"
	      };
	    }

	    var list_view_manager = new ListViewManager(
                              "Systems",
                              productUpdateList,
                              [10, 20, 30],
                              "#productUpdatePaginationCtrls",
                              "#productUpdateTable > tbody",
                              renderProductUpdateList,
                              sortHead,
                              sortObj,
                              null,
                              null,
                              {
                                columnGroups:
                                {
                                  0: { 0: { resize: true } },
                                  1: { 1: { resize: true } }
                                }
                              },
                              true,
                              1400
                            );

	    list_view_manager.generatePageControlHtml();

	    function renderProductUpdateList(parent, data, index) {

	      var tableRow = "",
            system = data[index],
            tabIndexOffset = (cmcApp.GENERAL_PAGE_FIRST_TAB_INDEX + 600 + (index * 3));

	      if (index % 2 == 0) {
	        tableRow += '<tr class="even">';
	      } else {
	        tableRow += '<tr class="odd">';
	      }

	      // group name
	      tableRow += '<td>';
	      tableRow += system['systemName'];
	      tableRow += '</td>';

	      // group description
	      tableRow += '<td>';
	      tableRow += (system['update'] == 'success' ? 'Yes' : 'No') ;
	      tableRow += '</td>';

	      tableRow += '</tr>';

	      parent.append(tableRow);
	    }

	  });

	}

	return {
		initialize : initialize,
		getInstalledProducts: getInstalledProducts,
		getProductLicenseState: getProductLicenseState,
		getSystemData:getSystemData,
	    initProductUpdate: initProductUpdate
	};
}();

window.onload = (function () {
   var licenseState = Header.getProductLicenseState();
   var notlicensed = 0;

   if (licenseState == 'None')  {
	   notlicensed = 2;
      var txt = document.getElementById("V_Main");
      if (null !== txt) {
          var newHTML = "DymaxIO <span style= 'color:#FF0000'> - Not Licensed </span>";
          txt.innerHTML = newHTML;
      }

   } else if (licenseState != 'Active')  {
	   notlicensed = 1;
      var txt = document.getElementById("V_Main");
      if (null !== txt) {
         var newHTML = "DymaxIO";
         txt.innerHTML = newHTML;
      }
   }

	if (notlicensed == 2) {
		var cururl = window.location.href;
		var cururlpos = cururl.search("LicenseManagement.html");
		if (cururlpos < 0) {
			window.location.assign("/Vlocity/License/LicenseManagement.html");
		}
	}
});
Header.GET_LISCENSE_SUMMARY_DONE = "getLicenseSummaryDone";
Header.HEADER_INITIALIZED = "headerIntialized";
