/*
!  Copyright (c) 2014 Condusiv Technologies Corporation, All Rights Reserved.
!
!  File: License.js
!
!  Description: - Code to support licenseing
!
! REVISION HISTORY:
!     9/06/2013 - James Yoon - Created
!     10/06/2015 � Dinsey Basil - UI for stand alone product
!     03/03/2017 � Rick Cadruvi - Add Product Authorization Code (PAC) handling
!     07/13/2020 - Rick Cadruvi - Go to 5 input boxes instead of 6
*/

/*
! Global Functions to support PAC license input
*/

/*******************************************************************************
! ROUTINE NAME:
!   pac_input_box
!
! REVISION HISTORY:
!     03/03/2017 � Rick Cadruvi - Created
!
! ROUTINE DESCRIPTION:
!     This routine accepts input from one of the 6 boxes in the form
!     that the user enters the PAC in and validates the data.  It will auto
!     uppercase and it also moves the input focus to the next box if all
!     is well and they filled the current.
!
! RETURNS: NONE
*******************************************************************************/
function pac_input_box
   (
   inputobj,   // I: Form Object
   curbox,     // I: Current Box name
   nextbox     // I: Next Box to set focus of when this one is done
   )
   {
   inputobj.value = inputobj.value.toUpperCase().replace(/[^2-9A-HJ-NP-Z]/g, '')
   if (inputobj.value.length == inputobj.maxLength)
      inputobj.form.elements[nextbox].focus();
/*
   var curok   = "false";
   var curlen  = inputobj.value.length;
   var curchar = inputobj.value.charAt(curlen-1);

   if ((curchar == 0) || (curchar == '-'))
      {
      inputobj.value = inputobj.value.substr (0, curlen-1); // remove invalid character
      inputobj.form.elements[curbox].focus();
      return;
      }

   if ((curchar >= 'a') && (curchar <= 'z'))
      {
      curchar = curchar.toUpperCase ();
      inputobj.value = inputobj.value.substr (0, curlen-1) + curchar;
      }

   if (((curchar >= '0') && (curchar <= '9')) ||
       ((curchar >= 'A') && (curchar <= 'Z')))
      { curok = "true"; }

   if (curok != "true")
      {
      alert ('Invalid Character "' + curchar + '" -- Must be 0-9 or A-Z');
      inputobj.value = inputobj.value.substr (0, curlen-1); // remove invalid character
      inputobj.form.elements[curbox].focus();
      return;
      }

   if (curlen == inputobj.maxLength)
      {
      inputobj.form.elements[nextbox].focus();
      }
*/
   }

/*******************************************************************************
! ROUTINE NAME:
!   pac_input_submit
!
! REVISION HISTORY:
!     03/03/2017 � Rick Cadruvi - Created
!
! ROUTINE DESCRIPTION:
!     This routine is called when the "Apply License" button is hit.
!     It gets the PAC string, validates it, and submits the PAC to the
!     backend code.
!
! RETURNS: NONE
*******************************************************************************/
function pac_input_submit
   (
   inputobj,   // I: Form Object
   formid      // I: Form ID name
   )
   {
   var results;
   var pacstring = "";

   pacstring = inputobj.form.elements[0].value + "-" +
               inputobj.form.elements[1].value + "-" +
               inputobj.form.elements[2].value + "-" +
               inputobj.form.elements[3].value + "-" +
               inputobj.form.elements[4].value;
//               inputobj.form.elements[4].value + "-" +
//               inputobj.form.elements[5].value;

   results = pac_submit_license_validate (pacstring);
   if (results == true)
      {
      pac_submit_license (pacstring);
      pac_reset (formid);
      return;
      }

   var confirmTitle   = "DymaxIO";
   var confirmMessage = "Invalid License Key: " + pacstring + " - Please try again.";
   var confirmButton = '<input class="btn main closeModal"  type="submit" value="OK" />';

   cmcApp.Lib.UIComponent.openConfirmModal(null, 'content', confirmTitle, confirmMessage, confirmButton,
        function ()
           {
           $('.closeModal').click(function () { $('#overlay').remove(); });
           });
   pac_reset (formid);
   inputobj.form.elements[0].focus();
   }

function pac_refresh_license_display ()
   {
   cmcApp.Lib.UIComponent.openWaitIndicator();

   var service = 'getLicenseSummary.json';
   var submiturl = '/Vlocity/Requests/';

// invoke http command get licens summary
   $.ajax({
      url: submiturl + service,
      contentType: "application/json",
      dataType: 'json',
      success: handleSuccess,
      error: handleError,
      type: "POST"
      });

   function handleSuccess(data)
      {
      cmcApp.Lib.UIComponent.closeWaitIndicator();

      var listOfLicenses = data['license'];

//      pac_refresh_license_display_do (listOfLicenses[0]);
      }


   function handleError(xhr, textStatus, errorThrown)
      {
      cmcApp.Lib.UIComponent.closeWaitIndicator();
      }
   }

function pac_refresh_license_display_do
   (
   license_to_display   // I: License data that we want to display
   )
   {
   var html;
   var key = license_to_display.key;
   if (key.length == 0) {
      key = "Not Yet Licensed - Please enter valid license";
   }
	if (key == "MRCWN-ARAZ6-JTAHL-4U9F3-EYFNL") {
		license_to_display.type = "Perpetual";
		license_to_display.state = "Active";
		license_to_display.expiration = "Never";
	}
   html  = '<div class="licenseList" >';
      html += '<div id="Link" class="licenseIndex0 licenseTile endLicenseTile ' +
              'clickableLicenseTile selected" tabindex="12101" index="0" ' +
              'style="width: 1194px;">';
         html += '<div class="licenseDescription">';
            html += '<table>' +
                       '<tbody>' +
                          '<tr>' +
//                             '<td width="250px">Edition</td>' +
//                             '<td>' + license_to_display.edition + '</td>' +
                             '<td width="250px">Key</td>' +
                             '<td>' + key + '</td>' +
                          '</tr>' +
                          '<tr>' +
//                             '<td width="250px">Type</td>' +
//                             '<td>' + License.NAME_BY_TYPE[license_to_display.type] + '</td>' +
                             '<td width="250px">Type</td>' +
                             '<td>' + license_to_display.type + '</td>' +
                          '</tr>' +
                          '<tr>' +
                             '<td width="250px">State</td>' +
                             '<td>' + license_to_display.state + '</td>' +
                          '</tr>' +
/*
                          '<tr>' +
                             '<td width="250px">Licensed By</td>' +
                             '<td>';
                     if (license_to_display.state == 'expired')
                        { html += '<font style="color:red;"><strong>EXPIRED</strong></font>'; }
                     else
                        { html += license_to_display.licensedBy; }

                html += '</td>' +
                          '</tr>' +
*/
                          '<tr>' +
                             '<td width="250px">Expires</td>' +
                             '<td>' + license_to_display.expiration + '</td>' +
                          '</tr>' +
                       '</tbody>' +
                    '</table>';
         html += '</div>';
      html += '</div>';
   html += '</div>';

// Output the HTML
   $('licensesStatusPlaceHolder').find('.licenseBlocks').empty().html(html);
return html;
   }
/*
                if (License.NAME_BY_TYPE[licenseSummaryObj.type] !== undefined) {
                    if (count % 3 == 0) {
                        if (isFirstLicenseList == true) {
                            licenseHtml += '<div class="licenseList" >';
                            isFirstLicenseList = false;
                        } else {
                            licenseHtml += '<div class="licenseList nofloat">';
                        }
                    }

                    if (count == len - 1) {
                        licenseHtml += " endLicenseTile";
                    } else if (count % 3 == 0) {
                        licenseHtml += " firstLicenseTile";
                    } else if (count % 3 == 2) {
                        licenseHtml += " lastLicenseTile";
                    } else if (count == len - 1 && count < 3) {
                        licenseHtml += " lastLicenseTile";
                    }

                    //if (_isOnDashboard) {
                    licenseHtml += " clickableLicenseTile";
                    //}

                    licenseHtml += '" tabindex="' + (cmcApp.LICENSE_FIRST_TAB_INDEX + 100 + count) + '"\
                           index="' + count + '">';


                    if (licenseSummaryObj.SN == "") {
                        licenseHtml += '<div class="licenseDescription">';
                        licenseHtml += 'Unlicensed DymaxIO Installations<BR>and Unlicensed Hypervisors';
                        licenseHtml += '</div>';

                        licenseHtml += '<div class="licenseAvailable">';
                        licenseHtml += 'Unlicensed:<span>' + licenseSummaryObj.allocated + '</span>';
                        licenseHtml += '</div>';

                    } else {
                        var tableRow = '';
                        licenseHtml += '<div class="licenseDescription">';
                        tableRow += '<tr>';
                        tableRow += '<td width="250px">';
                        tableRow += 'Edition';
                        tableRow += '</td>';
                        tableRow += '<td>';
                        tableRow += licenseSummaryObj.edition;
                        tableRow += '</td>';
                        tableRow += '</tr>';

                        tableRow += '<tr>';
                        tableRow += '<td width="250px">';
                        tableRow += 'Type';
                        tableRow += '</td>';
                        tableRow += '<td>';
                        tableRow += License.NAME_BY_TYPE[licenseSummaryObj.type];
                        tableRow += '</td>';
                        tableRow += '</tr>';

                        tableRow += '<tr>';
                        tableRow += '<td width="250px">';
                        tableRow += 'State';
                        tableRow += '</td>';
                        tableRow += '<td>';
                        tableRow += licenseSummaryObj.state;
                        tableRow += '</td>';
                        tableRow += '</tr>';



                        tableRow += '<tr>';
                        tableRow += '<td width="250px">';
                        tableRow += 'Licensed By';
                        tableRow += '</td>';
                        tableRow += '<td>';
                        tableRow += licenseSummaryObj.licensedBy;
                        tableRow += '</td>';
                        tableRow += '</tr>';

                        if (licenseSummaryObj.licensedBy != "Local") {
                            $(".addUpdateLicense").hide();
                        }
                        if (licenseSummaryObj.type != License.PERPETUAL_TYPE && licenseSummaryObj.type != License.UNKNOWN_TYPE) {
                            tableRow += '<tr>';
                            tableRow += '<td width="250px">';
                            tableRow += 'Expires';
                            tableRow += '</td>';
                            tableRow += '<td>';
                            if (licenseSummaryObj.state == 'expired') { //TODO make a mapping
                                tableRow += '<font style="color:red;"><strong>EXPIRED</strong></font>';
                            } else {
                                // licenseHtml += _job.convertDateToDateStr(_job.convertFiletimeToDate(licenseSummaryObj.expirationDate));
                                tableRow += licenseSummaryObj.expirationDate;
                            }
                            tableRow += '</td>';
                            tableRow += '</tr>';
                        }

                        licenseHtml += '<table>';
                        licenseHtml += tableRow;
                        licenseHtml += '</table>';
                        licenseHtml += '</div>';
                    }

                    licenseHtml += '</div>';

                    if (count % 3 == 2 || len == count - 1) {
                        licenseHtml += '</div>';
                    }

                    count++;
                }

            });

            $(_overviewDiv).find('.slides').empty().append(licenseHtml);

            // There is no callback function for the complete event of append().
            // So, it should give reasonable interval (0.1 sec) to render the slider UI properly.
            setTimeout(function () {
                $(_overviewDiv).find('.slideshow').wgSimpleSlideshow({ showNavigator: false });

                $('.licenseOverviewListBlock').find('.licenseListBlock').find('.licenseIndex0').addClass('selected');
            }, 100);

        } // end of if (len > 0)
        else {
            var noLicenseHtml = '<div class="noLicenseMsg" tabindex="' + (cmcApp.LICENSE_FIRST_TAB_INDEX + 100) + '"><p>A DymaxIO License has not been detected.</p><br>\
            <p>DymaxIO License has not been detected. You need to add a valid license to the CMC framework.</p>\
            <p>Download and place a valid license on the system where the CMC is installed at:</p><br>\
            <p>' + Header.getInstalledProducts().getRootPath() + '</p><br>';

            if (_isOnDashboard == false) {
                noLicenseHtml += '<p>If you have already placed a valid license at the location above, click the Check the Add / Rename Licenses button on this screen.</p>';
            }
            noLicenseHtml += '</div>'
            $(_overviewDiv).find('.slidesContainer').empty().append(noLicenseHtml);
*/

function pac_reset (formid)
   {
   var mydoc = document.getElementById(formid);

   for (i = 0; i < mydoc.elements.length - 1; i++)
      {
      mydoc.elements[i].value = "";
      }
   }

function pac_submit_license (realpacstring)
   {
   var return_status = true;

   cmcApp.Lib.UIComponent.openWaitIndicator();

   var service = 'addLicenseCode.json';
   var pacsubmiturl = '/Vlocity/UI/VM/Requests/';

   pacJson = new Object();
   pacJson.LicenseCode = realpacstring;

// invoke http command Add / Update licenses
   $.ajax({
      url: pacsubmiturl + service,
      contentType: "application/json",
      dataType: 'json',
      data: JSON.stringify(pacJson),
      success: handleSuccess,
      error: handleError,
      type: "POST"
      });

   function handleSuccess(data)
      {
      cmcApp.Lib.UIComponent.closeWaitIndicator();

      var confirmTitle = "DymaxIO";
      var confirmMessage = 'Successfully applied license key: ' + realpacstring;
      var confirmButton = '<input class="btn main closeModal"  type="submit" value="OK" />';

      if (data.Reason != "Success")
      {
         if (data.Error == "329")
            confirmMessage = 'Waiting for license server to respond.';
         else if (data.Error != "13" && data.Error != "34")
            confirmMessage = 'Unable to locate a valid DymaxIO license.';
         else
         {
            if (data.Error == "34")
               confirmMessage = 'License key is valid but not for this system or product.';
            else
               confirmMessage = 'Invalid License Key: ' + realpacstring + ' - Please try again.';
            return_status = false;
         }
      }
      cmcApp.Lib.UIComponent.openConfirmModal(null, 'content', confirmTitle, confirmMessage, confirmButton,
           function ()
              {
              $('.closeModal').click(function ()
                  {
                     $('#overlay').remove();
                     location.reload();   // reload page
                  });
              });

//      pac_refresh_license_display ();
      }

   function handleError(xhr, textStatus, errorThrown)
      {
      cmcApp.Lib.UIComponent.closeWaitIndicator();
      var confirmTitle   = "DymaxIO";
      var confirmMessage = "Invalid License Key: " + realpacstring + " - " + textStatus +
                           " message: " + errorThrown + " responseText: " + xhr.responseText +
                           " - Please try again.";
      var confirmButton = '<input class="btn main closeModal"  type="submit" value="OK" />';

      cmcApp.Lib.UIComponent.openConfirmModal(null, 'content', confirmTitle, confirmMessage, confirmButton,
           function ()
              {
              $('.closeModal').click(function () { $('#overlay').remove(); });
              });
      }
   }

function pac_submit_license_validate (realpacstring)
   {
//   if (realpacstring.length != 34) { return (false); }
   if (realpacstring.length != 29) { return (false); }
   if (realpacstring.substr (5, 1) != "-") { return (false); }
   if (realpacstring.substr (11, 1) != "-") { return (false); }
   if (realpacstring.substr (17, 1) != "-") { return (false); }
   if (realpacstring.substr (23, 1) != "-") { return (false); }
//   if (realpacstring.substr (29, 1) != "-") { return (false); }
   return (true);
   }

function License(allocationDiv, overviewDiv, PACDiv, product){

   var
      _allocationDiv = allocationDiv,
      _overviewDiv = overviewDiv,
      _PACDiv = PACDiv,
      _currentProduct = product,
      _self = this,
      _masterRequesURL = "/Vlocity/Requests/",
      _cmcCommonURL = '/Vlocity/Common/',
      _requestURL,
      _installedProducts,
      _systemsTableManager,
      _licenseListItems,
      _filteredlicensedListItems,
      _selectedLicenseListItems,
      _showCheckLicenseButton = true,
      _isOnDashboard = false,
      _allAvailableLicense,
      _currentSelectedLicenseSn,
      _existingLicenses = new Array(),
      _newLicenses = new Array(),
      _job = new Job(),
      _filter = {
          type: 'All',
          name: ''
        },
        LicenseSummaryObject = function () {
            this.SN = '';
            this.type = '';
            this.name = '';
            this.units = '';
            this.startdate = 0;
            this.expiration = 0;
            this.valid = false;
            this.available = 0;
            this.allocated = 0;
            this.index = 0;
            this.serverLicense = false;
            this.clientLicense = false;
        },

        LicensedSystemObject = function () {
            this.id = '';
            this.type = '';
            this.name = '';
            this.units = 0;
            this.VlocityVMs = 0;
            this.virtualMachines = 0;
            this.valid = false;
            this.expiration = 0;
            this.licenseType = '';
            this.SN = '';
            this.osType = '';
            this.os = '';
            this.managed_products = [];
        };

    //////////////////////////////////////////////////////////////////////////
    //                                PUBLIC API                              //
    //////////////////////////////////////////////////////////////////////////

    /**
     *  Initialize a object
     */
    this.initialize = function(){

        _installedProducts = Header.getInstalledProducts();

        // Set request URL based on current product
        if(_currentProduct !== undefined){
            _requestURL = window.PRDUIBASEPATH + _installedProducts.getProductByKey(_currentProduct).url + 'Requests/';

        }

        // Initialize Job object
        _job.setRequestUrl(_requestURL);
        _job.setMasterRequestUrl(_masterRequesURL);

        updateLicenseBlocks();
    }

    /**
     *  Get License Summary
     */
    this.getLicenseSummary = function(filterUnlicensed){

        var service = 'getLicenseSummary.json',
            licenseSummaryJson = new Object();

        $.ajax({
            url: _masterRequesURL + service,
            contentType: "application/json",
            //data: JSON.stringify(licenseSummaryJson),
            dataType: 'json',
            //cache: false,
            success: handleSuccess,
            error: handleError,
            type: "POST"
        });

        function handleSuccess(data) {

            var updatedData = data;
/*
            //filter unlicensed info, for the 'Add/Rename Licenses' and the 'Assign License' dialog box.
            if (filterUnlicensed !== undefined && filterUnlicensed == true) {
                updatedData['key'] = _.filter(data['key'], function (obj) { return obj.SN != "" });
            }
            // Sort data by product name descending order as default
            updatedData['key'].sort(function (a, b) {
                if (a['name'] < b['name']) {
                    return -1;
                } else if (a['name'] > b['name']) {
                    return 1;
                }
                return 0;
            });
*/
            $(_self).trigger(License.GET_LICENSE_SUMMARY_COMPLETE, [updatedData]);
        }

        function handleError(xhr, textStatus, errorThrown) {
            console.error(service + " " + textStatus + " message: " + errorThrown + " responseText: " + xhr.responseText);
            $(_self).trigger(License.GET_LICENSE_SUMMARY_COMPLETE, "fatal");
        }
    }

    /**
     *  Get Licensed Systems for the given product
     */
    this.getLicensedSystems = function(licensedSystemsJson, callback){

        var service = 'getLicensedSystems3.json';

        cmcApp.Lib.UIComponent.openWaitIndicator();

        $.ajax({
            url: _masterRequesURL + service,
            contentType: "application/json",
            data: JSON.stringify(licensedSystemsJson),
            dataType: 'json',
            //cache: false,
            success: handleSuccess,
            error: handleError,
            type: "POST"
        });

        function handleSuccess(data) {
            cmcApp.Lib.UIComponent.closeWaitIndicator();
            $(_self).trigger(License.GET_LICENSED_SYSTEMS_COMPLETE, [data, callback]);
        }

        function handleError(xhr, textStatus, errorThrown) {
            cmcApp.Lib.UIComponent.closeWaitIndicator();
            console.error(service + " " + textStatus + " message: " + errorThrown + " responseText: " + xhr.responseText);
            $(_self).trigger(License.GET_LICENSED_SYSTEMS_COMPLETE, "fatal");
        }
    }

    /**
     *  Reclaim license.
     *  Request reclaimLicense and send system IDs
     */
    this.reclaimLicense = function (reclaimJson, callback) {

        var service = 'reclaimLicense.json';

        $.ajax({
            url: _masterRequesURL + service,
            contentType: "application/json",
            data: JSON.stringify(reclaimJson),
            dataType: 'json',
            //cache: false,
            success: handleSuccess,
            error: handleError,
            type: "POST"
        });

        function handleSuccess(data) {
            $(_self).trigger(License.RECLAIM_LICENSE_COMPLETE, [data, callback]);
        }

        function handleError(xhr, textStatus, errorThrown) {
            console.error(service + " " + textStatus + " message: " + errorThrown + " responseText: " + xhr.responseText);
            $(_self).trigger(License.RECLAIM_LICENSE_COMPLETE, "fatal");
        }
    }


    /**
     *  get existing licenses
     */
    this.getNewLicenses = function () {

        var service = 'getNewLicenses.json';

        $.ajax({
            url: _masterRequesURL + service,
            contentType: "application/json",
            dataType: 'json',
            //cache: false,
            success: handleSuccess,
            error: handleError,
            type: "POST"
        });

        function handleSuccess(data) {
            $(_self).trigger(License.GET_NEW_LICENSES_COMPLETE, [data]);
        }

        function handleError(xhr, textStatus, errorThrown) {
            console.error(service + " " + textStatus + " message: " + errorThrown + " responseText: " + xhr.responseText);
            $(_self).trigger(License.GET_NEW_LICENSES_COMPLETE, "fatal");
        }
    }

    /**
     *  rename a license's name
     */
    this.renameLicense = function (sn, name) {

        var service = 'renameLicense.json',
            jsonObj = new Object();

        jsonObj.SN = sn;
        jsonObj.name = name;

        $.ajax({
            url: _masterRequesURL + service,
            contentType: "application/json",
            data: JSON.stringify(jsonObj),
            dataType: 'json',
            //cache: false,
            success: handleSuccess,
            error: handleError,
            type: "POST"
        });

        function handleSuccess(data) {
            $(_self).trigger(License.RENAME_LICENSE_COMPLETE, [data]);
        }

        function handleError(xhr, textStatus, errorThrown) {
            console.error(service + " " + textStatus + " message: " + errorThrown + " responseText: " + xhr.responseText);
            $(_self).trigger(License.RENAME_LICENSE_COMPLETE, "fatal");
        }
    }

    /**
     *  assign systems to the selected license
     */
    this.assignLicense = function (sn, systems) {

        var service = 'assignLicense.json',
            jsonObj = new Object();

        jsonObj.SN = sn;
        jsonObj.systems = systems;

        $.ajax({
            url: _masterRequesURL + service,
            contentType: "application/json",
            data: JSON.stringify(jsonObj),
            dataType: 'json',
            //cache: false,
            success: handleSuccess,
            error: handleError,
            type: "POST"
        });

        function handleSuccess(data) {
            $(_self).trigger(License.ASSIGN_LICENSE_COMPLETE, [data]);
        }

        function handleError(xhr, textStatus, errorThrown) {
            console.error(service + " " + textStatus + " message: " + errorThrown + " responseText: " + xhr.responseText);
            $(_self).trigger(License.ASSIGN_LICENSE_COMPLETE, "fatal");
        }
    }

    /**
     *  assign systems to the selected license
     */
    this.validateAssignLicense = function (sn, systems) {

        var service = 'validateAssignLicense.json',
            jsonObj = new Object();

        jsonObj.SN = sn;
        jsonObj.systems = systems;

        $.ajax({
            url: _masterRequesURL + service,
            contentType: "application/json",
            data: JSON.stringify(jsonObj),
            dataType: 'json',
            //cache: false,
            success: handleSuccess,
            error: handleError,
            type: "POST"
        });

        function handleSuccess(data) {
            $(_self).trigger(License.VALIDATE_ASSIGN_LICENSE_COMPLETE, [data]);
        }

        function handleError(xhr, textStatus, errorThrown) {
            console.error(service + " " + textStatus + " message: " + errorThrown + " responseText: " + xhr.responseText);
            $(_self).trigger(License.VALIDATE_ASSIGN_LICENSE_COMPLETE, "fatal");
        }
    }

    /**
     *  add a new license
     */
    this.addLicense = function (fileName, licenseName) {

        var service = 'addLicense.json',
            jsonObj = new Object(),
            SNs = new Array();

        jsonObj.fileName = fileName;
        jsonObj.licenseName = licenseName;

        $.ajax({
            url: _masterRequesURL + service,
            contentType: "application/json",
            data: JSON.stringify(jsonObj),
            dataType: 'json',
            //cache: false,
            success: handleSuccess,
            error: handleError,
            type: "POST"
        });

        function handleSuccess(data) {
            $(_self).trigger(License.ADD_LICENSE_COMPLETE, [data]);
        }

        function handleError(xhr, textStatus, errorThrown) {
            console.error(service + " " + textStatus + " message: " + errorThrown + " responseText: " + xhr.responseText);
            $(_self).trigger(License.ADD_LICENSE_COMPLETE, "fatal");
        }
    }


    /**
     *  remove a selected license
     */
    this.removeLicense = function (sn) {

        var service = 'removeLicense.json',
            jsonObj = new Object();

        jsonObj.SN = sn;

        $.ajax({
            url: _masterRequesURL + service,
            contentType: "application/json",
            data: JSON.stringify(jsonObj),
            dataType: 'json',
            //cache: false,
            success: handleSuccess,
            error: handleError,
            type: "POST"
        });

        function handleSuccess(data) {
            $(_self).trigger(License.REMOVE_LICENSE_COMPLETE, [data]);
        }

        function handleError(xhr, textStatus, errorThrown) {
            console.error(service + " " + textStatus + " message: " + errorThrown + " responseText: " + xhr.responseText);
            $(_self).trigger(License.REMOVE_LICENSE_COMPLETE, "fatal");
        }
    }

    /**
     *  Check and return the license type
     */
    this.getLicenseType = function () {
        $(_self).bind(License.GET_LICENSE_SUMMARY_COMPLETE, function (event, data, callback) {

            var aLicense,
                licenseType,
                isTrial = true,
                  license;

            for (var i = 0; i < data['license'].length; i++) {

                aLicense = data['license'][i];
                if (aLicense['type'] != License.TRIAL_TYPE) {
                    isTrial = false;
                }
            }
            if (isTrial == true) {
                licenseType = License.TRIAL_VERSON;
            } else {
                licenseType = License.FULL_VERSION;
            }
            $(_self).trigger(License.GET_LICENSE_TYPE_COMPLETE, [licenseType, callback]);

        });
        _self.getLicenseSummary();
    }

    /**
     *  Set the visibility of 'Check For New Licenses' button
     */
    this.setCheckLicenseButtonVisibility = function(value){
        _showCheckLicenseButton = value;
    }

    /**
     *  Set _isOnDashboard value for clicking the product of the tile
     */
    this.setIsOnDashboard = function(value){
        _isOnDashboard = value;
    }

    //////////////////////////////////////////////////////////////////////////
    //                               PRIVATE METHODS                          //
    //////////////////////////////////////////////////////////////////////////

    /**
     *  Execute update license blocks (overview or systems if exists)
     */
    function updateLicenseBlocks() {

        _selectedLicenseListItems = new Object();

        var $allocationPlaceHolder = $(_allocationDiv);
        if ($allocationPlaceHolder !== undefined) {
            $allocationPlaceHolder.empty().addClass('block').addClass('primary').addClass('licenseAllocationList');
            initLicenseAllocationPlaceHolder($allocationPlaceHolder);
        }

        var $overviewPlaceHolder = $(_overviewDiv);
        if ($overviewPlaceHolder !== undefined) {
            $overviewPlaceHolder.empty().addClass('block').addClass('primary').addClass('licensesStatus');
            initLicenseOverviewPlaceHolder($overviewPlaceHolder);

            $(_self).bind(License.GET_LICENSE_SUMMARY_COMPLETE, onGetLicenseSummaryComplete);
            _self.getLicenseSummary();
        }

        var $PACPlaceHolder = $(_PACDiv);
        if ($PACPlaceHolder !== undefined) {
            $PACPlaceHolder.empty().addClass('block').addClass('primary').addClass('PACInput');
            initPACPlaceHolder($PACPlaceHolder);
        }

    }

    /**
     *  Event handler for License.GET_LICENSE_SUMMARY_COMPLETE
     *  Populate Licensing overview section and the dropdown menu
     */
    function onGetLicenseSummaryComplete(event, data, callback){

        $(_self).unbind(License.GET_LICENSE_SUMMARY_COMPLETE, onGetLicenseSummaryComplete);

//        var listOfLicense = data['license'];
        var listOfLicense = data;

        var aLicense,
            listOfSystems,
            system,
            licenseSummaryObj,
            tempLicenseSummaryObj,
            today = new Date();
/*
        _allAvailableLicense = new Object();

        for (var i = 0; i < listOfLicense.length; i++) {

            aLicense = listOfLicense[i];

            licenseSummaryObj = new LicenseSummaryObject();
            licenseSummaryObj.SN = '1'; //TODO Remove and clean up code based on it.
            licenseSummaryObj.edition = aLicense['edition'];
            licenseSummaryObj.licenseType = aLicense['licenseType'];
            licenseSummaryObj.expirationDate = aLicense['expirationDate'];
            licenseSummaryObj.type = aLicense['type'];
            licenseSummaryObj.state = aLicense['state'];
            licenseSummaryObj.daysRemaining = aLicense['daysRemaining'];
            licenseSummaryObj.licensedBy = aLicense['licensedBy'];
            /*
            licenseSummaryObj.serverLicense = Number(aLicense['serverLicense']) == 1 ? true : false;
            licenseSummaryObj.clientLicense = Number(aLicense['clientLicense']) == 1 ? true : false;
            */ /*
            if (licenseSummaryObj.SN == "") {
                licenseSummaryObj.index = 0;
                _currentSelectedLicenseSn = licenseSummaryObj.SN;
            } else {
                licenseSummaryObj.index = (i + 1);
            }
            if (_allAvailableLicense[licenseSummaryObj.SN] !== undefined && _allAvailableLicense[licenseSummaryObj.SN] != null) {
                console.log('duplicated license found');
            }

            _allAvailableLicense[licenseSummaryObj.SN] = licenseSummaryObj;
        }
*/
        populateLicenseOverview(data);
/*
        if (_allocationDiv != null) {
            updateSelectTypeMenu();

            getSystemsByLicense("");  // blank means unlicensed systems
        }
*/
    }

    function getSystemsByLicense(sn) {

        cmcApp.Lib.UIComponent.openWaitIndicator();

        // Get licensed systems
        $(_self).bind(License.GET_LICENSED_SYSTEMS_COMPLETE, onGetLicensedSystemsComplete);

        var licensedSystemsJson = new Object();
        licensedSystemsJson.SN = sn;
        _self.getLicensedSystems(licensedSystemsJson);

    }

    /**
     *  Event handler for License.GET_LICENSED_SYSTEMS_COMPLETE
     *  It will populates License Allocation table based on filter option
     */
    function onGetLicensedSystemsComplete(event, data, callback){

        var system,
            licensedSystemObj;

        cmcApp.Lib.UIComponent.closeWaitIndicator();

        $(_self).unbind(License.GET_LICENSED_SYSTEMS_COMPLETE, onGetLicensedSystemsComplete);

        _licenseListItems = new Array();

        for (var i = 0; i < data['systems'].length; i++) {

            system = data['systems'][i];

            licensedSystemObj = new LicensedSystemObject();
            licensedSystemObj.id = system['id'];
            licensedSystemObj.type = system['type'];
            licensedSystemObj.name = system['name'];
            licensedSystemObj.units = system['units'];
            licensedSystemObj.VlocityVMs = Number(system['VlocityVMs']);
            licensedSystemObj.virtualMachines = Number(system['virtualMachines']);
            licensedSystemObj.valid = Boolean(system['valid']);
            licensedSystemObj.licenseType = system['licenseType'];
            licensedSystemObj.SN = system['SN'];
            licensedSystemObj.expiration = Number(system['expiration']);
            licensedSystemObj.osType = system['osType'];
            licensedSystemObj.managed_products = system['managed_products'];

            //If a Hypervisor does not have DymaxIO installed on it,
            //we obviously do not scan the Hypervisor, and we will need to show Unknown as the OS for these.
            /*
            if (licensedSystemObj.type == "1" || licensedSystemObj.type == 1) {
              if (licensedSystemObj.managed_products != null && licensedSystemObj.managed_products.length > 0) {
                licensedSystemObj.os = system['os'];
              } else {
                licensedSystemObj.os = 'Unknown';
              }

            } else {
              */
            licensedSystemObj.os = system['os'];
            //}

            _licenseListItems.push(licensedSystemObj);

        }

        _selectedLicenseListItems = new Object();

        $('.licenseActionLink').addClass('disabled');

        filterLicenseListItems();
    }

    /**
     *  Populate Licensing Overview section
     */
    function populateLicenseOverview(licenseList) {

        var html = '',
            licenseHtml = '',
            count = 0,
            expireDate,
            len = 0,
            isFirstLicenseList = true,
            todayDate = new Date(),
            licenseSummaryObj;

    licenseHtml = pac_refresh_license_display_do (licenseList);

        if (licenseList !== undefined && licenseList != null) {
            len = Object.keys(licenseList).length;
        }

        if (len > 0) {
            //for (var sn in licenseList) {
            Object.keys(licenseList).sort().forEach(function (sn) {
                //console.log(licenseList[sn]);

                licenseSummaryObj = licenseList[sn];

                if (License.NAME_BY_TYPE[licenseSummaryObj.type] !== undefined) {
                    if (count % 3 == 0) {
                        if (isFirstLicenseList == true) {
                            licenseHtml += '<div class="licenseList" >';
                            isFirstLicenseList = false;
                        } else {
                            licenseHtml += '<div class="licenseList nofloat">';
                        }
                    }

                    licenseHtml += '<div id="' + name + 'Link" class="licenseIndex' + count + ' licenseTile';
                    if (count == len - 1) {
                        licenseHtml += " endLicenseTile";
                    } else if (count % 3 == 0) {
                        licenseHtml += " firstLicenseTile";
                    } else if (count % 3 == 2) {
                        licenseHtml += " lastLicenseTile";
                    } else if (count == len - 1 && count < 3) {
                        licenseHtml += " lastLicenseTile";
                    }

                    //if (_isOnDashboard) {
                    licenseHtml += " clickableLicenseTile";
                    //}

                    licenseHtml += '" tabindex="' + (cmcApp.LICENSE_FIRST_TAB_INDEX + 100 + count) + '"\
                           index="' + count + '">';


                    if (licenseSummaryObj.SN == "") {
                        licenseHtml += '<div class="licenseDescription">';
                        licenseHtml += 'Unlicensed DymaxIO Installations<BR>and Unlicensed Hypervisors';
                        licenseHtml += '</div>';

                        licenseHtml += '<div class="licenseAvailable">';
                        licenseHtml += 'Unlicensed:<span>' + licenseSummaryObj.allocated + '</span>';
                        licenseHtml += '</div>';

                    } else {
                        var tableRow = '';
                        licenseHtml += '<div class="licenseDescription">';
                        tableRow += '<tr>';
                        tableRow += '<td width="250px">';
                        tableRow += 'Edition';
                        tableRow += '</td>';
                        tableRow += '<td>';
                        tableRow += licenseSummaryObj.edition;
                        tableRow += '</td>';
                        tableRow += '</tr>';

                        tableRow += '<tr>';
                        tableRow += '<td width="250px">';
                        tableRow += 'Type';
                        tableRow += '</td>';
                        tableRow += '<td>';
                        tableRow += License.NAME_BY_TYPE[licenseSummaryObj.type];
                        tableRow += '</td>';
                        tableRow += '</tr>';

                        tableRow += '<tr>';
                        tableRow += '<td width="250px">';
                        tableRow += 'State';
                        tableRow += '</td>';
                        tableRow += '<td>';
                        tableRow += licenseSummaryObj.state;
                        tableRow += '</td>';
                        tableRow += '</tr>';



                        tableRow += '<tr>';
                        tableRow += '<td width="250px">';
                        tableRow += 'Licensed By';
                        tableRow += '</td>';
                        tableRow += '<td>';
                        tableRow += licenseSummaryObj.licensedBy;
                        tableRow += '</td>';
                        tableRow += '</tr>';

                        if ((licenseSummaryObj.licensedBy != "Local") ||         // licensed by CMC
                            (License.PERPETUAL_TYPE == licenseSummaryObj.type)) { // licensed FULL version, both cases hide PAC entry part
                            $(".addUpdateLicense").hide();
                            document.getElementById('packeydiv').style.display = "none";

                        }
                        if (licenseSummaryObj.type != License.PERPETUAL_TYPE && licenseSummaryObj.type != License.UNKNOWN_TYPE) {
                            tableRow += '<tr>';
                            tableRow += '<td width="250px">';
                            tableRow += 'Expires';
                            tableRow += '</td>';
                            tableRow += '<td>';
                            if (licenseSummaryObj.state == 'expired') { //TODO make a mapping
                                tableRow += '<font style="color:red;"><strong>EXPIRED</strong></font>';
                            } else {
                                // licenseHtml += _job.convertDateToDateStr(_job.convertFiletimeToDate(licenseSummaryObj.expirationDate));
                                tableRow += licenseSummaryObj.expirationDate;
                            }
                            tableRow += '</td>';
                            tableRow += '</tr>';
                        }

                        licenseHtml += '<table>';
                        licenseHtml += tableRow;
                        licenseHtml += '</table>';
                        licenseHtml += '</div>';
                    }

                    licenseHtml += '</div>';

                    if (count % 3 == 2 || len == count - 1) {
                        licenseHtml += '</div>';
                    }

                    count++;
                }

            });

            $(_overviewDiv).find('.slides').empty().append(licenseHtml);

            // There is no callback function for the complete event of append().
            // So, it should give reasonable interval (0.1 sec) to render the slider UI properly.
            setTimeout(function () {
                $(_overviewDiv).find('.slideshow').wgSimpleSlideshow({ showNavigator: false });

                $('.licenseOverviewListBlock').find('.licenseListBlock').find('.licenseIndex0').addClass('selected');
            }, 100);

        } // end of if (len > 0)

        else {
            var noLicenseHtml = '<div class="noLicenseMsg" tabindex="' + (cmcApp.LICENSE_FIRST_TAB_INDEX + 100) + '"><p>A DymaxIO License has not been detected.</p><br>\
            <p>DymaxIO License has not been detected. You need to add a valid license to the CMC framework.</p>\
            <p>Download and place a valid license on the system where the CMC is installed at:</p><br>\
            <p>' + Header.getInstalledProducts().getRootPath() + '</p><br>';

            if (_isOnDashboard == false) {
                noLicenseHtml += '<p>If you have already placed a valid license at the location above, click the Check the Add / Rename Licenses button on this screen.</p>';
            }
            noLicenseHtml += '</div>'
            $(_overviewDiv).find('.slidesContainer').empty().append(noLicenseHtml);
        }

    }


    /**
     *  Populate system type dropdown menu in License Allocation section
     */
    function updateSelectTypeMenu() {

        var systemTypeMenuOptionHtml = '';

        systemTypeMenuOptionHtml += "<option value='All' selected>All</option>";
        systemTypeMenuOptionHtml += "<option value='" + License.HYPERVISOR_SYSTEM_TYPE + "'>" + License.SYSTEM_TYPE[License.HYPERVISOR_SYSTEM_TYPE] + "s</option>";
        systemTypeMenuOptionHtml += "<option value='" + License.PHYSICAL_SYSTEM_TYPE + "'>" + License.SYSTEM_TYPE[License.PHYSICAL_SYSTEM_TYPE] + "s</option>";
        systemTypeMenuOptionHtml += "<option value='" + License.VIRTUAL_MACHINE_TYPE + "'>" + License.SYSTEM_TYPE[License.VIRTUAL_MACHINE_TYPE] + "s</option>";

        $('#selectSystemType').empty().append(systemTypeMenuOptionHtml).selectpicker();
    }

    /**
     *  Initialize License Overview section without populate data
     */
    function initLicenseOverviewPlaceHolder(placeHolder){

        var html = '';

        html += '<div class="blockHeader">';
        html += '<h2 tabindex="' + cmcApp.LICENSE_FIRST_TAB_INDEX + '">Licensing Overview</h2>';
        if (_showCheckLicenseButton == true) {
            html += '<a href="#" class="btn main addUpdateLicense" tabindex="' + (cmcApp.LICENSE_FIRST_TAB_INDEX + 2) + '">Add / Update Licenses</a>';
        }
        html += '</div>';
        html += '<div class="licenseOverviewListBlock blockBody">';
        html += '<div class="slideshow">';
        html += '<div class="slidesContainer">';
        html += '<div id="licenseBlocks" class="slides licenseListBlock">';
        html += '<div class="licenseList">';
        html += '</div>';
        html += '</div>';
        html += '</div>';
        html += '</div>';
        html += '</div>';

        placeHolder.append(html);
    }

    /**
     *  Initialize Product Authorization Code section without populate data
     */
function initPACPlaceHolder(placeHolder)
   {

   var html = '';

   if (_showCheckLicenseButton == true)
      {
      html += '<div class="blockHeader5" id="packeydiv">';
      html += '<h2 tabindex="' + cmcApp.LICENSE_FIRST_TAB_INDEX+3 + '">Enter License Key ';
      html += '<form id="packey">';
         html += '<input type="text", name="pac1", maxLength="5", size="4", autofocus="autofocus",' ;
         html += '       onkeyup="pac_input_box(this, \'pac1\', \'pac2\');"/> <b>-</b> ';
         html += '<input type="text", name="pac2", maxLength="5", size="4", ';
         html += '       onkeyup="pac_input_box(this, \'pac2\', \'pac3\');"/> <b>-</b> ';
         html += '<input type="text", name="pac3", maxLength="5", size="4", ';
         html += '       onkeyup="pac_input_box(this, \'pac3\', \'pac4\');"/> <b>-</b> ';
         html += '<input type="text", name="pac4", maxLength="5", size="4", ';
         html += '       onkeyup="pac_input_box(this, \'pac4\', \'pac5\');"/> <b>-</b> ';
         html += '<input type="text", name="pac5", maxLength="5", size="4", ';
         html += '       onkeyup="pac_input_box(this, \'pac5\', \'pactbn\');"/> <b>-</b> ';
//         html += '<input type="text", name="pac5", maxLength="5", size="4", ';
//         html += '       onkeyup="pac_input_box(this, \'pac5\', \'pac6\');"/> <b>-</b> ';
//         html += '<input type="text", name="pac6", maxLength="4", size="2", ';
//         html += '       onkeyup="pac_input_box(this, \'pac6\', \'pacbtn\');"/> ';
         html += '<input type="button", name="pacbtn", class="btn main PACApplyLicense", ';
         html += 'value="Apply License", onclick="pac_input_submit(this, \'packey\');" />';
      html += '</form>';
      html+= '</h2>';

      html += '</div>';
      }

   placeHolder.append(html);
   }

    /**
     * Initialize License Allocation section without populate data
     */
    function initLicenseAllocationPlaceHolder(placeHolder){

        var headerHtml = '';

        headerHtml += '<div class="blockHeader">';
        headerHtml += '<h2 tabindex="' + (cmcApp.LICENSE_FIRST_TAB_INDEX + 200) + '"><strong>Systems Assigned to Selected License</strong></h2>';
        headerHtml += '<ul class="formDetails horizontalLayout" >';
        headerHtml += '<li class="formElement" style="margin-top: 8px;">';
        headerHtml += '<input id="systemName" type="text" placeholder="Find a System" title="Find a system" tabindex="' + (cmcApp.LICENSE_FIRST_TAB_INDEX + 201) + '"/>';
        headerHtml += '</li>';
        headerHtml += '<li class="formElement" style="margin-top: 8px;">';
        headerHtml += '<div style="position: relative; display:inline-block; width: 24px; height: 24px;">';
        headerHtml += '<img class="imgTagForAlt" title="Find a system" style="position: absolute; float:left; left: 0px;">';
        headerHtml += '</img>';
        headerHtml += '<input class="btn search" type="submit" value="search" id="searchSystem" title="Find a system button" tabindex="' + (cmcApp.LICENSE_FIRST_TAB_INDEX + 202) + '"/>';
        headerHtml += '</div>';
        headerHtml += '</li>';
        headerHtml += '<li class="formElement" id="systemTypeSelectHolder">';
        headerHtml += '<select id="selectSystemType" name="" class="selectpicker" tabindex="' + (cmcApp.LICENSE_FIRST_TAB_INDEX + 203) + '">';
        headerHtml += '</select>';
        headerHtml += '</li>';
        headerHtml += '</ul>';
        headerHtml += '</div>';

        headerHtml += '<div style="height: 25px; margin: 5px 10px 5px 10px; position: relative;">';
        headerHtml += '<div id="licensePaginationCtrls"></div>';
        headerHtml += '<div class="actions dropdown-select">\
                    <button class="btn dropdown-toggle dropdown-select dropdown-focus" data-toggle="dropdown" type="button" tabindex="1020">\
                      <span class="dropdown-label">Actions</span>\
                      <i class="arrow down white"></i>\
                    </button>\
                    <ul class="dropdown-menu" style="width:180px">\
                      <li><a class="licenseActionLink disabled dropdown-option reclaim" href="#">Reclaim License</a>\
                      </li>\
                      <li><a class="licenseActionLink disabled dropdown-option assign" href="#">Assign to License</a>\
                      </li>\
                    </ul>\
                  </div>';
        headerHtml += '</div>';
        headerHtml += '<div class="blockBody">';
        headerHtml += '<table id="licenseAllocationListTable" tabindex="' + (cmcApp.LICENSE_FIRST_TAB_INDEX + 400) + '">';
        headerHtml += '<thead>';
        headerHtml += generateTableHeaderHtml();
        headerHtml += '</thead>'
        headerHtml += '<tbody>'
        headerHtml += generateEmptyRows();
        headerHtml += '</tbody>'
        headerHtml += '</table>'
        headerHtml += '</div>';

        placeHolder.append(headerHtml);

        // Apply select picker style to html selection
        setTimeout(function (){
            $('#selectAction').selectpicker({ title: "Action" });
        }, 500);

    }

    /**
     *  Generate a table header html
     */
    function generateTableHeaderHtml(){

        var tableHeaderHtml = "";

        tableHeaderHtml += "<tr class='colHdr'>";

        tableHeaderHtml += "<th scope='col' class='sortable'>\
                        <div><input type='checkbox' class='tableColumnCheckbox' id='sysAll'/>\
                             System Name<span class='arrow down'></span>\
                        </div></th>";

        tableHeaderHtml += "<th scope='col' class='sortable'><div>Operating System<span class='arrow down'></span></div></th>";

        tableHeaderHtml += "<th scope='col' class='sortable'><div>System Type<span class='arrow down'></span></div></th>";

        tableHeaderHtml += "<th scope='col' class='sortable'><div># of Units<span class='arrow down'></span></div></th>";

        tableHeaderHtml += "<th scope='col' class='sortable'><div>Expiration Date<span class='arrow down'></span></div></th>";

        tableHeaderHtml += "</tr>";

        return tableHeaderHtml;
    }

    /**
     *  Generate empty table row html to keep the table height while loading data
     */
    function generateEmptyRows(){

        var tableRows = '';

        for(var i = 0; i < 10; i++){
            if (i % 2 == 0) {
                tableRows += '<tr class="even">';
            } else {
                tableRows += '<tr class="odd">';
            }
            tableRows += '<td colspan="5"></td>';
            tableRows += '</tr>';
        }

        return tableRows;
    }

    /**
     *  Update license allocation table with pagination
     */
    function updateLicenseTable(data){

        $('table#licenseAllocationListTable > thead').empty().append(generateTableHeaderHtml());

        $('#licensePaginationCtrls').empty();

        var sortHead;
        var sortObj;

        if (data != null && data.length > 0) {
            sortHead = "table#licenseAllocationListTable > thead";
            sortObj = {
                0: "name",
                1: "os",
                2: "type",
                3: "units",
                4: function (ascending) {
                    var mod = ascending ? 1 : -1;
                    var prop = "expiration";
                    return function (a, b) {
                        var aExp = a["valid"] ? a[prop] : -1,
                            bExp = b["valid"] ? b[prop] : -1;
                        if (aExp > bExp) {
                            return 1 * mod;
                        } else if (aExp < bExp) {
                            return -1 * mod;
                        }
                        return 0;
                    }
                }
            };
        }

        _systemsTableManager = new ListViewManager(
                                                                    "",
                                                                    data,
                                                                    [10, 20, 30],
                                                                    "#licensePaginationCtrls",
                                                                    "table#licenseAllocationListTable > tbody",
                                                                    addLicenseRow,
                                    sortHead,
                                    sortObj,
                                    null,
                                    null,
                                    null,
                                    true,
                                    (cmcApp.LICENSE_FIRST_TAB_INDEX + 300)
                                                                );

        _systemsTableManager.generatePageControlHtml();

        if (data == null || data.length == 0) {
            //Add empty row
            $('table#licenseAllocationListTable > tbody').empty().append('<tr><td></td><td></td><td></td><td></td><td></td></tr>');
        }
    }

    /**
     *  Callback function for ListViewManager to generate 1 row
     */
    function addLicenseRow(parent, data, index) {

        var tableRow = '',
            system = data[index],
            checked = false,
            tabIndexOffset = ((cmcApp.LICENSE_FIRST_TAB_INDEX + 1000) + (index * 1));

        if (index % 2 == 0) {
            tableRow += '<tr class="even">';
        } else {
            tableRow += '<tr class="odd">';
        }

        // System name
        tableRow += '<td>';
        tableRow += '<input type="checkbox" class="tableColumnCheckbox" name="sys1" id="' + system['id'] + '" />';
        tableRow += '<a href="#" class="gotoSystemDetailBySystemNameLink" system-id="' + system['id'] + '" system-name="' + system['name'] + '" tabindex="' + (tabIndexOffset + 1) + '" >' + system['name'] + '</a>';
        tableRow += '</td>';

        // OS
        tableRow += '<td>';
        tableRow += system['os'];
        tableRow += '</td>';

        // System type
        tableRow += '<td>';
        tableRow += License.SYSTEM_TYPE[system['type']];
        tableRow += '</td>';

        // # of Cores
        tableRow += '<td>';
        tableRow += system['units'] + '</td>';

        // Expiration
        tableRow += '<td>';
        if (system['SN'] != "" && system['licenseType'] != License.PERPETUAL_TYPE) { // subscription or trial license

            if (system['valid'] == false || system['expiration'] == 0) {
                tableRow += '<font style="color:red;"><strong>EXPIRED</strong></font></td>';
            } else {
                tableRow += _job.convertDateToDateStr(_job.convertFiletimeToDate(system['expiration'])) + '</td>';
            }
        } else {
            tableRow += 'N/A</td>';
        }

        tableRow += '</tr>';

        parent.append(tableRow);
    }

    /**
     *  Search systems by system name that is input in the search text box
     */
    function searchSystemByName() {
        var $name = $('#systemName').val().trim();

        _filter.name = $name;

        filterLicenseListItems();

    }

    /**
     *  Apply filter to the current license allocation table
     */
    function filterLicenseListItems(){

        var system,
            show,
            sysName,
            cards,
            idx,
            typeSearch,
            nameSearch,
            isWildsearch,
            searchWord;

        _filter.type = $('#selectSystemType').val();

        if (_filter.type == 'All' && _filter.name == '') {
            _filteredlicensedListItems = _licenseListItems;

        } else {

            _filteredlicensedListItems = new Array();

            typeSearch = _filter.type != 'All';
            nameSearch = _filter.name != '';

            isWildsearch = _filter.name.indexOf('*') > -1;

            searchWord = _filter.name;

            searchWord = searchWord.toLowerCase();

            for (var i = 0; i < _licenseListItems.length; i++) {

                system = _licenseListItems[i];
                sysName = $.trim(system.name);

                sysName = sysName.toLowerCase();

                show = false;

                if (typeSearch == true && system.type == _filter.type) {
                    show = true;
                }

                if (nameSearch == true) {

                    if (isWildsearch == true) {
                        show = wildcardMatch(sysName, searchWord) && (typeSearch == true ? show : true);
                    } else {
                        show = (sysName == searchWord) && (typeSearch == true ? show : true);
                    }
                }

                if (show == true){
                    _filteredlicensedListItems.push(system);
                }
            }
        }

        updateLicenseTable(_filteredlicensedListItems);
    }

    /**
     *  Wildcard Search function
     */
    function wildcardMatch(text, pattern) {

        var cards = pattern.split("\*"),
            card;

        for (var i = 0; i < cards.length; i++) {

            card = cards[i];

            idx = (i == (cards.length - 1)) ? text.lastIndexOf(card) : text.indexOf(card);

            // pattern : Sys*
            // search text: System 1, extraSystem
            // expected result: System 1
            // Withouth this logic, it will return both System 1 and extraSystem
            if (i == 0 && card != "" && idx != 0) {
                return false;
            }

            if (idx == -1) {
                return false;
            }

            text = text.substring(idx + card.length);

            // pattern: Sys*1
            // seach text: System 1, System 11
            // expected result: System 1, System 11
            // Without this logic it will return only System 1
            //
            // That's why idx is set by lastIndexOf or indexOf based on the current i
            //
            if (i == (cards.length - 1) && text != "") {
                return false;
            }
        }

        return true;
    }

    /**
     *  Open confirm modal window for user if she/he wants to assign license
     */
    function openAssignLicenseConfirmModal(selectedSystems) {

        var license,
            messageHtml,
            licenseRadioHtml = '',
            disabled,
            licenseName,
            licenseObj,
            currentLicenseName,
            hasValidLicense = false;

        licenseObj = _allAvailableLicense[_currentSelectedLicenseSn];

        if (licenseObj !== undefined && licenseObj != null && licenseObj.SN != "") {
            currentLicenseName = licenseObj.name;
        } else {
            currentLicenseName = "No License Assigned";
        }

        $(_self).bind(License.GET_LICENSE_SUMMARY_COMPLETE, function f1(event1, data1) {

            $(_self).unbind(License.GET_LICENSE_SUMMARY_COMPLETE, f1);

            licenseRadioHtml += '<div class="licenseRadioBlock">';
            for (var j = 0; j < data1["license"].length; j++) {
                license = data1["license"][j];

                if (license.valid == false) {
                    disabled = 'disabled';
                    licenseName = license.name + ' - Expired';
                } else {
                    disabled = '';
                    licenseName = license.name;
                    hasValidLicense = true;
                }

                licenseRadioHtml +=
                  '<div class="radioBlock ' + disabled + '"><label><input name="licenseSelectRadio" type="radio"\
                value="' + license.SN + '" \
                   class="licenseSelect" ' + disabled + '>\
          ' + licenseName + '</label></div>';
            }
            licenseRadioHtml += '</div>';

            if(hasValidLicense == false){
                openNoValidLicenseIssue();
            } else {
                cmcApp.Lib.UIComponent.openModal(null, _cmcCommonURL + 'LicenseAssignModal.html', 'content', function () {

                    messageHtml =
                      '<div class="assignLicenseBlock bottomLine"><p>Use the controls below to assign a license to your selected system(s).</p></div>\
           <div class="assignLicenseBlock bottomLine">\
                 <p>Current assigned license:<BR></p>\
                 <div class="currentLicenseName"><i>' + currentLicenseName  + '</i></div>\
           </div>\
           <div class="assignLicenseBlock" ><p>Available Licenses:</p>\
           ' + licenseRadioHtml + '\
           </div>';

                    $('#assignLicenseBody').html(messageHtml);

                    $('.assignBtn').click(function ($e) {

                        var $this = $(this),
                            sn;

                        sn = $('input[type="radio"][name="licenseSelectRadio"]:checked').val();

                        $('#overlay').remove();

                        verifySelectedSystemsAreSameOsTypeForAssignLicense(selectedSystems, sn);

                    });

                });
            }

        });

        _self.getLicenseSummary(true);
    }

    function executeAssignLicense(sn, selectedSystems) {

        $(_self).bind(License.ASSIGN_LICENSE_COMPLETE, function f1(event, data) {
            $(_self).unbind(License.ASSIGN_LICENSE_COMPLETE, f1);

            cmcApp.Lib.UIComponent.closeWaitIndicator();

            updateLicenseBlocks();

        });

        _self.assignLicense(sn, selectedSystems);
    }

    function openNoValidLicenseIssue(){
        var issues_modal = new IssuesModal(
                      "NoValidLicenseIssue",
                      [],
                      {
                          title: "Issue Found",
                          content: "<p>There are currently no available valid (non-expired) license\
                               to perform this assignment task.<BR><BR>\
                               Add a valid license to the DymaxIO and try again.</p>",

                          cancel_button_text: "Cancel",
                          show_more: false,
                          has_next_button: false,
                      }
                  );

        issues_modal.doModal();
    }

    function openNotEnoughLicenseIssue(message){
        var issues_modal = new IssuesModal(
                      "NotEnoughLicenseIssue",
                      [],
                      {
                          title: "Issue Found",
                          content: "<p>Unable to assign your selected systems to the new license that you have selected.<BR><BR>\
                               " + message + "</p>",

                          cancel_button_text: "Cancel",
                          show_more: false,
                          has_next_button: false,
                      }
                  );

        issues_modal.doModal();
    }

    /**
     *  Open confirm modal window for user if she/he wants to reclaim license
     */
    function openReclaimLicenseConfirmModal($e) {

        var system,
            selectedSystems = new Array();

        for (var i = 0; i < _licenseListItems.length; i++) {

            system = _licenseListItems[i];

            if (_selectedLicenseListItems[system.id] !== undefined &&
                _selectedLicenseListItems[system.id] != null) {
                selectedSystems.push(system);
            }
        }

        cmcApp.Lib.UIComponent.openModal($e, _cmcCommonURL+'LicenseModal.html', 'confirmGroup', function(){

            var headerHtml = 'Reclaim License';
            var messageHtml = '';

            messageHtml = '<p>Reclaiming a license from the selected systems will remove their current\
                     license assignment.</p><BR>\
                     <p>Systems with unlicensed DymaxIO installations may no longer receive\
                     performance benefits until they are assigned to a valid license. Alerts will\
                     be generated for these systems until they are assigned to a valid license\
                     or DymaxIO is uninstalled from these systems.<p><BR>\
                     <p>Do you want to continue reclaiming the license assignment from these\
                     systems?</p>';

            var buttonsHTML = '<input class="btn closeModal" type="reset" value="Cancel" />' +
                              '<input class="btn main" id="reclaimBtn" type="submit" value="OK"/>';

            $('.confirmHeader').html(headerHtml);
            $('.confirmMsg p').html(messageHtml);
            $('.confirmButtons').html(buttonsHTML);

            $('#reclaimBtn').click(function ($e) {
                $('#overlay').remove();
                verifySelectedSystemsForReclaimLicense(selectedSystems)
            });

        });
    }

    /**
     *  Verify selected systems to be qualified for a Upgarde job
     */
    function verifySelectedSystemsForReclaimLicense(selectedSystems) {

        var wrong_sys_type = [],
            right_sys_type = [],
            sys,
            managedProducts,
            product,
            isRightSystem,
            sysText1,
            sysText2;

        for (var i = 0; i < selectedSystems.length; i++) {
            isRightSystem = true;

            sys = selectedSystems[i];

            if (sys.type !== undefined && sys.type != null) {

                if (sys.type == License.VIRTUAL_MACHINE_TYPE) {
                    isRightSystem = false;
                }
            }

            if (isRightSystem == true) {
                right_sys_type.push(sys);
            } else {
                wrong_sys_type.push(sys);
            }
        }

        if (wrong_sys_type.length > 0) {

            if (right_sys_type.length == 0) { // all are wrong
                var issues_modal = new IssuesModal(
                          "reclaimIssues",
                          wrong_sys_type,
                          {
                              title: "Issue Found",
                              content: "<p>All of the systems in your selection are identified as Virtual\
                            Machines. To reclaim license units for these systems, you \
                            need to reclaim the license assigned to their associated Hypervisor.</p><BR>\
                            <p>You can not proceed with this task.</p>",

                              cancel_button_text: "Cancel",
                              show_more: false,
                              has_next_button: false,
                          }
                      );
            } else {

                sysText1 = wrong_sys_type.length + ((wrong_sys_type.length == 1) ? " system that is" : " systems that are");
                sysText2 = (wrong_sys_type.length == 1) ? "this system" : "these systems";

                var issues_modal = new IssuesModal(
                      "reclaimIssues",
                      wrong_sys_type,
                      {
                          title: "Issue Found",
                          content: "<p>We detected " + sysText1 + " identified as Virtual\
                        Machines. To reclaim license units for " + sysText2 + ", you\
                       need to reclaim the license assigned to their associated Hypervisor.</p><BR>\
                         <p>Would you like to proceed without the identified systems?</p>",
                          cancel_button_text: "Cancel",
                          next_button_text: "Proceed without System(s)",
                          next_button_callback: function ($e) {
                              $e.preventDefault();
                              executeReclaimLicense(right_sys_type);
                          },
                          columns: ['System<br />Name'],
                          columnClass: ['colName'],
                          columnWidth: ['100%']
                      }
                  );
            }
            issues_modal.doModal();
        } else {
            executeReclaimLicense(right_sys_type);
        }
    }

    /**
     *  Verify is selected systems are not VM to be qualified for assigning license
     */
    function verifySelectedSystemsAreNotVmForAssignLicense($e) {

        var system,
            selectedSystems = new Array();

        for (var i = 0; i < _licenseListItems.length; i++) {

            system = _licenseListItems[i];

            if (_selectedLicenseListItems[system.id] !== undefined &&
                _selectedLicenseListItems[system.id] != null) {
                selectedSystems.push(system);
            }
        }

        var wrong_sys_type = [],
            right_sys_type = [],
            sys,
            managedProducts,
            product,
            isRightSystem,
            sysText1,
            sysText2;

        for (var i = 0; i < selectedSystems.length; i++) {
            isRightSystem = true;

            sys = selectedSystems[i];

            if (sys.type !== undefined && sys.type != null) {

                if (sys.type == License.VIRTUAL_MACHINE_TYPE) {
                    isRightSystem = false;
                }
            }

            if (isRightSystem == true) {
                right_sys_type.push(sys);
            } else {
                wrong_sys_type.push(sys);
            }
        }

        if (wrong_sys_type.length > 0) {

            if (right_sys_type.length == 0) { // all are wrong
                var issues_modal = new IssuesModal(
                          "reclaimIssues",
                          wrong_sys_type,
                          {
                              title: "Issue Found",
                              content: "<p>All of the systems in your selection are identified as Virtual\
                            Machines. Virtual Machines are licensed through their association to hypervisor.\
                            Make sure these systems are associated to their appropriate hypervisor and that\
                            the hypervisor is assigned to a valid license.</p><BR>\
                            <p>You can not proceed with this task.</p>",

                              cancel_button_text: "Cancel",
                              show_more: false,
                              has_next_button: false,
                          }
                      );
            } else {

                sysText1 = wrong_sys_type.length + ((wrong_sys_type.length == 1) ? " system that is" : " systems that are");
                sysText2 = (wrong_sys_type.length == 1) ? "this system" : "these systems";

                var issues_modal = new IssuesModal(
                      "reclaimIssues",
                      wrong_sys_type,
                      {
                          title: "Issue Found",
                          content: "<p>We detected " + sysText1 + " identified as Virtual\
                        Machines. Virtual Machines are licensed through their association to hypervisor.\
                        Make sure these systems are associated to their appropriate hypervisor and that\
                        the hypervisor is assigned to a valid license.</p><BR>\
                         <p>Would you like to proceed without the identified systems?</p>",
                          cancel_button_text: "Cancel",
                          next_button_text: "Proceed without System(s)",
                          next_button_callback: function ($e) {
                              $e.preventDefault();
                              openAssignLicenseConfirmModal(right_sys_type);
                          },
                          columns: ['System<br />Name'],
                          columnClass: ['colName'],
                          columnWidth: ['100%']
                      }
                  );
            }
            issues_modal.doModal();
        } else {
            openAssignLicenseConfirmModal(right_sys_type);
        }
    }

    /**
     *  Verify if selected systems are same OS type ("clent" or "server") for assigning license
     */
    function verifySelectedSystemsAreSameOsTypeForAssignLicense(selectedSystems, sn) {

        var licenseSummaryObj,
            wrong_sys_type = [],
            right_sys_type = [],
            sys,
            managedProducts,
            product,
            isRightSystem,
            sysText1,
            sysText2,
            isInclusiveLicense = false,
            isServerLicense = false,
            isClientLicense = false,
            licenseOsType = "",
            unsupportedLicenseOsType = "";

        licenseSummaryObj = _allAvailableLicense[sn];

        if (licenseSummaryObj.serverLicense == false && licenseSummaryObj.clientLicense == false) {
            isInclusiveLicense = true;
        } else if (licenseSummaryObj.serverLicense == true) {
            isServerLicense = true;
            licenseOsType = "Server OS";
            unsupportedLicenseOsType = "Client OS";
        } else if (licenseSummaryObj.clientLicense == true) {
            isClientLicense = true;
            licenseOsType = "Client OS";
            unsupportedLicenseOsType = "Server OS";
        }

        for (var i = 0; i < selectedSystems.length; i++) {
            isRightSystem = true;

            sys = selectedSystems[i];

            if (sys.osType !== undefined && sys.osType != null) {

                if (sys.osType == "client") {
                    if (isServerLicense == true) {
                        isRightSystem = false;
                    }
                } else if (sys.osType == "server") {
                    if (isClientLicense == true) {
                        isRightSystem = false;
                    }
                }
            }

            if (isRightSystem == true) {
                right_sys_type.push(sys);
            } else {
                wrong_sys_type.push(sys);
            }
        }

        if (wrong_sys_type.length > 0) {

            if (right_sys_type.length == 0) { // all are wrong
                var issues_modal = new IssuesModal(
                      "assignIssues",
                      wrong_sys_type,
                      {
                          title: "Issue Found",
                          content: "<p>All of the systems in your selection have a " + unsupportedLicenseOsType + ". \
                        The license selected for assignment is applicable only for a " + licenseOsType + ".</p><BR>\
                        <p>You can not proceed with this task.</p>",

                          cancel_button_text: "Cancel",
                          show_more: false,
                          has_next_button: false,
                      }
                  );
            } else {

                sysText1 = wrong_sys_type.length + ((wrong_sys_type.length == 1) ? " system has" : " systems have");
                sysText2 = (wrong_sys_type.length == 1) ? "this system" : "these systems";

                var issues_modal = new IssuesModal(
                      "reclaimIssues",
                      wrong_sys_type,
                      {
                          title: "Issue Found",
                          content: "<p>We detected " + sysText1 + " a " + unsupportedLicenseOsType + ". The license \
                        selected for assignment is applicable only for a " + licenseOsType + ".</p><BR>\
                         <p>Would you like to proceed without the identified systems?</p>",
                          cancel_button_text: "Cancel",
                          next_button_text: "Proceed without System(s)",
                          next_button_callback: function ($e) {
                              $e.preventDefault();
                              executeValidateAssignLicense(right_sys_type, sn);
                          },
                          columns: ['System<br />Name'],
                          columnClass: ['colName'],
                          columnWidth: ['100%']
                      }
                  );
            }
            issues_modal.doModal();
        } else {
            executeValidateAssignLicense(right_sys_type, sn);
        }
    }

    /**
     *  Excute validateAssignLicense before assigning license
     */
    function executeValidateAssignLicense(selectedSystems, sn) {

        var systems = new Array();

        for (var i = 0; i < selectedSystems.length; i++) {
            systems.push(selectedSystems[i].id);
        }

        cmcApp.Lib.UIComponent.openWaitIndicator();

        $(_self).bind(License.VALIDATE_ASSIGN_LICENSE_COMPLETE, function f1(event, data) {
            $(_self).unbind(License.VALIDATE_ASSIGN_LICENSE_COMPLETE, f1);

            cmcApp.Lib.UIComponent.closeWaitIndicator();

            if (data.result == "error") {
                openNotEnoughLicenseIssue(data.message);
            } else {
                executeAssignLicense(sn, systems);
            }

        });

        _self.validateAssignLicense(sn, systems);
    }

    /**
     *  Show the message for the result of reclaim license
     */
    function openUninstalledLicenseModal($e, cores, product){
        cmcApp.Lib.UIComponent.openModal($e, _cmcCommonURL+'LicenseModal.html', 'confirmGroup', function(){

            var productName = getProductName(product);
            var headerHtml = 'Reclaimed ' + productName + ' License Confirmation';
            var messageHtml = 'You have reclaimed ' + cores + ' core licenses from a hypervisor. These licenses have been added to your pool of available licenses.';
            var buttonsHTML = '<input class="btn closeModal" type="reset" value="OK" />';

            $('.confirmHeader').html(headerHtml);
            $('.confirmMsg p').html(messageHtml);
            $('.confirmButtons').html(buttonsHTML);
        });
    }

    /**
     *  Get product name for the given product key
     */
    function getProductName(product){
        var name = '';
        if (cmcApp.Help.product.isVM(product)) {
            name = 'DymaxIO VM';
        } else if (cmcApp.Help.product.isServer(product)) {
            name = 'DymaxIO Server';
        } else if (cmcApp.Help.product.isCMC(product)) {
            name = 'CMC';
        }
        return name;
    }

    /**
     *  execute reclaimLicense ajax call and handle for the result
     */
    function executeReclaimLicense(selectedSystems){

        var system,
            systems = new Array(),
            reclaimJson = new Object();

        for (var i = 0; i < selectedSystems.length; i++) {
            system = selectedSystems[i];
            systems.push(system.id);
        }

        cmcApp.Lib.UIComponent.openWaitIndicator();

        $(_self).bind(License.RECLAIM_LICENSE_COMPLETE, function (event, data, callback){

            cmcApp.Lib.UIComponent.closeWaitIndicator();
            $(_self).unbind(License.RECLAIM_LICENSE_COMPLETE);

            cmcApp.Lib.UIComponent.openModal(null, _cmcCommonURL+'LicenseModal.html', 'confirmGroup', function(){

                var productName = getProductName(product);

                var headerHtml = 'License Reclaimed';
                var messageHtml = 'Your license has been reclaimed from your selected system(s).';
                var buttonsHTML = '<input class="btn main closeReclaimConfirmModal" type="reset" value="OK" />';

                $('.confirmHeader').html(headerHtml);
                $('.confirmMsg p').html(messageHtml);
                $('.confirmButtons').html(buttonsHTML);

                $('.closeReclaimConfirmModal').click(function ($e) {

                    $('#overlay').remove();

                    $e.preventDefault();
                    updateLicenseBlocks();
                });
            });

        });

        reclaimJson.systems = systems;

        _self.reclaimLicense(reclaimJson);
    }

    /**
     *  generate a license title by a license type
     *
     *  perpetual (if total is -1) : "Site"
     *  perpetual (if total is not -1) : "Volume"
     *  subscription: "Subscription"
     *  trial: "Subscription"
     */
    function getLicenseTitle(type) {
        var licenseTitle = "";
        if (type == License.PERPETUAL_TYPE) {
            if (isSite == true) {
                licenseTitle = License.NAME_BY_TYPE["site"];
            } else {
                licenseTitle = License.NAME_BY_TYPE["volume"];
            }
        } else {
            licenseTitle = License.NAME_BY_TYPE[type];
        }
        return licenseTitle;
    }

    /**
     *
     */
    function openAddRenameModal($e) {

        //cmcApp.Lib.UIComponent.openConfirmModal(null, 'content', title, message, buttons, function () {
        cmcApp.Lib.UIComponent.openModal(null, _cmcCommonURL+'LicenseAddRenameModal.html', 'content', function(){
            updateExistingAndNewLicensesTables();

            $('.closeModal').click(function ($e) {
                $('#overlay').remove();
            });

            $('.okAddRenameModal').click(function ($e) {
                $('#overlay').remove();
                updateLicenseBlocks();
            });
        });
    }

    /**
     *
     */
    function updateExistingAndNewLicensesTables() {

        $(_self).bind(License.GET_LICENSE_SUMMARY_COMPLETE, function f1(event1, data1) {

            $(_self).unbind(License.GET_LICENSE_SUMMARY_COMPLETE, f1);

            $(_self).bind(License.GET_NEW_LICENSES_COMPLETE, function f2(event2, data2) {

                $(_self).unbind(License.GET_NEW_LICENSES_COMPLETE, f2);

                updateNewLicenseTable(data2);
            });

            _self.getNewLicenses();

            updateExistingLicenseTable(data1);

        });

        _self.getLicenseSummary(true);
    }

    /**
     *
     */
    function updateExistingLicenseTable(data) {

        $("#existingLicensePageControls").empty();

        _existingLicenses = data['license'];

        var list_view_manager =
          new ListViewManager({
              title: "Existing Licenses",
              data: _existingLicenses,
              page_sizes: [5, 10, 15],
              page_ctrls_div_selector: "#existingLicensePageControls",
              list_view_div_selector: "#existingLicenseTable > tbody",
              generate_item_html_func: addExistingLicenseRow,
              table_header_div_selector: "#existingLicenseTable > thead",
              sortable_columns: {
                  0: "name"
              },
              has_actions: false
          });

        function addExistingLicenseRow(parent, data, index) {

            var tableRow = '',
                license = data[index];

            if (index % 2 == 0) {
                tableRow += '<tr class="even">';
            } else {
                tableRow += '<tr class="odd">';
            }

            tableRow += '<td>';
            tableRow += license['name'];
            tableRow += '<a class="renameLicenseLink" name="' + license['name'] + '" sn="' + license['SN'] + '">Rename</a>';
            tableRow += '</td>';
            tableRow += '</tr>';

            parent.append(tableRow);
        }

        list_view_manager.generatePageControlHtml();
    }

    /**
     *
     */
    function updateNewLicenseTable(data) {

        $("#newLicensePageControls").empty();

        _newLicenses = data['newLicenses'];

        var list_view_manager =
          new ListViewManager({
              title: "New Licenses",
              data: _newLicenses,
              page_sizes: [5, 10, 15],
              page_ctrls_div_selector: "#newLicensePageControls",
              list_view_div_selector: "#newLicenseTable > tbody",
              generate_item_html_func: addNewLicenseRow,
              table_header_div_selector: "#newLicenseTable > thead",
              sortable_columns: {
                  0: "name"
              },
              has_actions: false
          });

        function addNewLicenseRow(parent, data, index) {

            var tableRow = '',
                license = data[index];

            if (index % 2 == 0) {
                tableRow += '<tr class="even">';
            } else {
                tableRow += '<tr class="odd">';
            }

            tableRow += '<td>';
            tableRow += license['fileName'];
            tableRow += '<a class="addLicenseLink" fileName="' + license['fileName'] + '" >Add License</a>';
            tableRow += '</td>';
            tableRow += '</tr>';

            parent.append(tableRow);
        }

        list_view_manager.generatePageControlHtml();
    }

    /**
     *  open "Add / Rename Licenses" modal window
     */
    function openRenameLicenseModal(sn, name) {

        var title,
            message,
            buttons,
            modalStructure,
            $overlay,
            isUnique,
            newName;

        title = 'Rename License';
        message =
          '<p>To change the name of your license, type in a new, unique name below.</p>\
       <div style="margin: 10px auto 10px auto;">\
          <label id="licenseNameError" class="invalid"></label>\
          <input id="renameLicenseInputText" type="text" tabindex="29005" value="' + name + '"\
            style="width: 100%; height: 25px; padding: 4px; margin-top: 5px;" />\
       </div>';
        buttons =
          '<input class="btn closeCommonModal" type="reset" value="Cancel"  tabindex="29998" />\
       <input class="btn main proceedRename" type="submit" value="OK" tabindex="29999"/>';

        modalStructure =
          '<div class="commonModalOverlay">\
        <div class="background"></div>\
        <div class="commonModalMain"></div>\
      </div>';

        $('.content').append(modalStructure);

        $overlay = $('.commonModalOverlay');

        $overlay.find('.commonModalMain').load(_cmcCommonURL + 'CommonModal.html', cmcApp.postObj, function () {

            $('.commonHeader').html(title);
            $('.commonBody').html(message);
            $('.commonButtons').html(buttons);

            $('.proceedRename').click(function ($e) {
                $e.preventDefault();

                newName = $.trim($('#renameLicenseInputText').val());

                isUnique = isUniqueLicenseName(newName);

                if (!isUnique) {
                    $('#licenseNameError').html('This field cannot be empty and your license name must be unique.');
                    $('#renameLicenseInputText').css({ "border": "1px red solid" });
                } else {
                    $('#licenseNameError').html('');

                    cmcApp.Lib.UIComponent.openWaitIndicator();

                    $(_self).bind(License.RENAME_LICENSE_COMPLETE, function f1(event, data) {

                        $(_self).unbind(License.RENAME_LICENSE_COMPLETE, f1);

                        if (data.result == "success") {

                            $('.commonModalOverlay').remove();

                            updateExistingAndNewLicensesTables();

                        } else {
                            $('#licenseNameError').html(data.message);
                            $('#renameLicenseInputText').css({ "border": "1px red solid" });
                        }

                        cmcApp.Lib.UIComponent.closeWaitIndicator();
                    });

                    _self.renameLicense(sn, newName);
                }

            });

            $('.closeCommonModal').click(function ($e) {
                $('.commonModalOverlay').remove();
            });

            $('#renameLicenseInputText').focusin(function () {
                $('#licenseNameError').html('');
                $('#renameLicenseInputText').css({ "border": "1px solid #aaa" });
            });

        });
    }

    /**
     *  Check if the name is in existing or new license name list.
     */
    function isUniqueLicenseName(inputName) {

        var isUnique = true,
            licenseObj;

        if (inputName == "") isUnique = false;

        licenseObj = _.findWhere(_existingLicenses, { name: inputName });

        if (licenseObj) {
            isUnique = false;
        } else {
            licenseObj = _.findWhere(_newLicenses, { name: inputName });
            if (licenseObj) {
                isUnique = false;
            }
        }

        return isUnique;
    }

    /**
     *  Add a new license
     */
    function executeAddLicense(fileName) {


        var title,
            message,
            buttons,
            modalStructure,
            $overlay,
            isUnique,
            licenseName;

        title = 'Add License';
        message =
          '<p>To add a license, you must name it. Type in a new, unique name below and\
          then click OK to add your license</p>\
       <div style="margin: 10px auto 10px auto;">\
          <label id="licenseNameError" class="invalid"></label>\
          <input id="renameLicenseInputText" type="text" tabindex="29005" value=""\
            style="width: 100%; height: 25px; padding: 4px; margin-top: 5px;" />\
       </div>';
        buttons =
          '<input class="btn closeCommonModal" type="reset" value="Cancel"  tabindex="29998" />\
       <input class="btn main proceedRename" type="submit" value="OK" tabindex="29999"/>';

        modalStructure =
          '<div class="commonModalOverlay">\
        <div class="background"></div>\
        <div class="commonModalMain"></div>\
      </div>';

        $('.content').append(modalStructure);

        $overlay = $('.commonModalOverlay');

        $overlay.find('.commonModalMain').load(_cmcCommonURL + 'CommonModal.html', cmcApp.postObj, function () {

            $('.commonHeader').html(title);
            $('.commonBody').html(message);
            $('.commonButtons').html(buttons);

            $('.proceedRename').click(function ($e) {
                $e.preventDefault();

                licenseName = $.trim($('#renameLicenseInputText').val());

                isUnique = isUniqueLicenseName(licenseName);

                if (!isUnique) {
                    $('#licenseNameError').html('This field cannot be empty and your license name must be unique.');
                    $('#renameLicenseInputText').css({ "border": "1px red solid" });
                } else {
                    $('#licenseNameError').html('');

                    cmcApp.Lib.UIComponent.openWaitIndicator();

                    $(_self).bind(License.ADD_LICENSE_COMPLETE, function f1(event, data) {

                        $(_self).unbind(License.ADD_LICENSE_COMPLETE, f1);

                        if (data.result == "success") {

                            $('.commonModalOverlay').remove();

                            updateExistingAndNewLicensesTables();

                        } else {
                            $('#licenseNameError').html(data.message);
                            $('#renameLicenseInputText').css({ "border": "1px red solid" });
                        }

                        cmcApp.Lib.UIComponent.closeWaitIndicator();
                    });

                    _self.addLicense(fileName, licenseName);
                }

            });

            $('.closeCommonModal').click(function ($e) {
                $('.commonModalOverlay').remove();
            });

            $('#renameLicenseInputText').focusin(function () {
                $('#licenseNameError').html('');
                $('#renameLicenseInputText').css({ "border": "1px solid #aaa" });
            });

        });

    }

    /**
     *  Execute remove license (if the selected license is valid)
     */
    function executeRemoveLicense() {

        if (_currentSelectedLicenseSn != "") {
            var title = 'Remove License',
                body = '',
                buttons = '';

            body = '<p>All Systems that are assigned to the selected license will become \
              unlicensed.</p><BR>\
            <p>Are you sure you want to remove the selected license from the CMC?</p>';

            buttons = '<input class="btn closeModal" type="reset" value="Cancel" />' +
                      '<input class="btn main continue" type="submit" value="OK"/>';


            cmcApp.Lib.UIComponent.openConfirmModal(null, 'content', title, body, buttons, function () {

                $('.closeModal').click(function ($e) {
                    $('#overlay').remove();
                });

                $('.continue').click(function ($e) {
                    $('#overlay').remove();

                    cmcApp.Lib.UIComponent.openWaitIndicator();

                    $(_self).bind(License.REMOVE_LICENSE_COMPLETE, function f1(event, data) {

                        $(_self).unbind(License.REMOVE_LICENSE_COMPLETE, f1);

                        cmcApp.Lib.UIComponent.closeWaitIndicator();

                        showRemoveLicenseResult(data);
                    });

                    _self.removeLicense(_currentSelectedLicenseSn);
                });

            });
        }
    }

    /**
     *
     */
    function showRemoveLicenseResult(data) {
        var result = data['result'],
            title = 'License Remove Confirmation',
            message = '<p>The selected License has been removed.</p>',
            buttons = '<input class="btn main closeModal" type="submit" value="OK" tabindex="29999" />';


        if (result == 'error') {
            title = 'Attention';
            message = '<p>We are unable to remove the selected license at this time.\
                 Please try again later.<br></p>';
        }

        cmcApp.Lib.UIComponent.openConfirmModal(null, 'content', title, message, buttons, function () {

            $('.closeModal').click(function ($e) {
                $('#overlay').remove();

                updateLicenseBlocks();
            });

        });
    }

    //////////////////////////////////////////////////////////////////////////
    //                             UI EVENT HANDLERS                          //
    //////////////////////////////////////////////////////////////////////////

    /**
     *  Click handler for the 'Licensing Overview' section and
     *  update the table according to the selected product (DymaxIO VM, Server, etc)
     */
    $('body').on('click keypress', '.clickableLicenseTile', function ($e) {

        var $this = $(this),
            index,
            sn;

        if ($e.type == 'click' || $e.which == 13) {
            $e.preventDefault();

            if (_isOnDashboard == true) {
                window.location = "/Vlocity/License/LicenseManagement.html";
            } else {

                index = $this.attr('index');
                sn = $this.attr('sn');

                $('.licenseOverviewListBlock .licenseListBlock').find('.licenseTile').each(function ($e) {
                    $(this).removeClass('selected');
                });

                $('.licenseOverviewListBlock .licenseListBlock').find('.licenseIndex' + index).addClass('selected');

                _currentSelectedLicenseSn = sn;

                if (_currentSelectedLicenseSn == "") {
                    $('.removeLicense').addClass('disabled');
                } else {
                    $('.removeLicense').removeClass('disabled');
                }

                getSystemsByLicense(sn);
            }
        }
    });

    /**
     *  Click event handler for 'Add / Update licenses'
     */
    $('body').on('keypress click', '.addUpdateLicense', function ($e) {

        if ($e.type == 'click' || $e.which == 13) {

            $e.preventDefault();

            var $this = $(this);

            var service = 'addUpdateLicense.json';
            var pacsubmiturl = '/Vlocity/UI/VM/Requests/';
            // invoke http command Add / Update licenses
            $.ajax({
//                url: _requestURL + service,
                  url: pacsubmiturl + service,
                contentType: "application/json",
                dataType: 'json',
                success: handleSuccess,
                error: handleError,
                type: "POST"
            });

            function handleSuccess(data) {
                // re-fetch license data
                updateLicenseBlocks();

                var confirmTitle = "DymaxIO";
                var confirmMessage = 'Successfully completed Add / Update licenses.';
                var confirmButton = '<input class="btn main closeModal"  type="submit" value="OK" />';

                if (data.Reason != "Success")
                {
                   if (data.Error == "329")
                      confirmMessage = 'Waiting for license server to respond.';
                   else
                      confirmMessage = 'Unable to locate a valid DymaxIO license.';
                }

                cmcApp.Lib.UIComponent.openConfirmModal(null, 'content', confirmTitle, confirmMessage, confirmButton, function () {
                    $('.closeModal').click(function () { $('#overlay').remove();});
                });
            }

            function handleError(xhr, textStatus, errorThrown) {
                console.error(service + " " + textStatus + " message: " + errorThrown + " responseText: " + xhr.responseText);
            }
        }
    });


    /**
     *  Change event handler for 'Actions' dropdown menu in pagination control section
     */
    $('body').on('click', '.licenseActionLink', function ($e) {

        $e.preventDefault();

        var $this = $(this);

        if ($this.hasClass("disabled")) return;

        var value = $this.val();

        if ($this.hasClass("reclaim")){
            openReclaimLicenseConfirmModal($e);
        } else if ($this.hasClass("assign")) {
            verifySelectedSystemsAreNotVmForAssignLicense($e);
        }

    });

    /**
     *  Change event handler for individual checkbox
     */
    //$('body').on('change', 'input[name=sys1]', function ($e) {
    $('body').on('click', 'input[name=sys1]', function ($e) {

        var $this = $(this),
            id = $this.attr('id'),
            sys,
              begin = -1,
              end = -1,
              beginFound = false;

        if ($e.shiftKey) {
            console.log('shift key pressed!');

            if (_systemsTableManager != null && _systemsTableManager.data != null) {

                for (var i = 0; i < _systemsTableManager.data.length; i++) {
                    sys = _systemsTableManager.data[i];

                    if (_selectedLicenseListItems[sys.id] && _selectedLicenseListItems[sys.id].checked == true) {
                        if (id != sys.id && beginFound == false) {
                            begin = i;
                            beginFound = true;
                        } else {
                            end = i;
                        }
                    } else {
                        if (id == sys.id && beginFound == false) {
                            begin = i;
                            beginFound = true;
                        } else if (id == sys.id && beginFound == true) {
                            end = i;
                            break;
                        }
                    }
                }
            }
        }
        //console.log('begin = ' + begin + ' end = ' + end);

        if (begin != -1 && end != -1 && begin >= 0 && end < _systemsTableManager.data.length) {

            for (var i = 0; i < _systemsTableManager.data.length; i++) {

                sys = _systemsTableManager.data[i];

                if (i >= begin && i <= end) {
                    _selectedLicenseListItems[sys.id] = {
                        checked: true,
                        id: id
                    };

                    $('input.tableColumnCheckbox[type=checkbox][id=' + sys.id + ']').prop('checked', true);
                } else {
                    delete _selectedLicenseListItems[sys.id];
                    $('input.tableColumnCheckbox[type=checkbox][id=' + sys.id + ']').prop('checked', false);
                }
            }

        } else {
            if ($this.prop('checked') == true) {
                _selectedLicenseListItems[id] = {
                    checked: true,
                    id: id
                };
            } else {
                delete _selectedLicenseListItems[id];
            }
        }

        var selectedLicenseSize = Object.keys(_selectedLicenseListItems).length;

        $('#sysAll').prop('checked', (selectedLicenseSize == _filteredlicensedListItems.length));

        if (selectedLicenseSize > 0) {
            $('.licenseActionLink').removeClass('disabled');

            if (_currentSelectedLicenseSn == "") {
                $('.licenseActionLink.reclaim').addClass('disabled');
            }

        } else {
            $('.licenseActionLink').addClass('disabled');
        }

    });

    /**
     *  Change event handler for select all checkbox
     */
    $('body').on('change', '#sysAll', function () {

        var $this = $(this),
            checked = ($this.prop('checked') == true);

        _selectedLicenseListItems = new Object();

        if (checked) {
            var license;

            for (var i = 0; i < _licenseListItems.length; i++) {

                license = _licenseListItems[i];
                _selectedLicenseListItems[license.id] = {
                    checked: true,
                    cores: license.cores,
                    installedVMs: license.VlocityVMs
                };
            }
            $('.licenseActionLink').removeClass('disabled');

            if (_currentSelectedLicenseSn == "") {
                $('.licenseActionLink.reclaim').addClass('disabled');
            }

        } else {
            $('.licenseActionLink').addClass('disabled');
        }

        $('input[name=sys1]').prop('checked', checked);

    });

    /**
     *  Click event handler for 'Remove Selected License' button in 'Licensing Overview' section
     */
    $('body').on('click keypress', '.removeLicense', function ($e) {

        if ($e.type == 'click' || $e.which == 13) {
            $e.preventDefault();

            executeRemoveLicense();
        }
    });

    /**
     *  Click event handler for search button in 'Licensing Allocation' section
     */
    $('body').on('click keypress', '#searchSystem', function ($e) {

        if ($e.type == 'click' || $e.which == 13) {
            $e.preventDefault();

            searchSystemByName();
        }
    });

    /**
     *  Keydown event handler for search name input text
     *  If key iput code is 13 (enter), it triggers the search function
     */
    $('body').on('keydown', '#systemName', function ($e) {

        if ($e.keyCode == 13) {

            searchSystemByName();
        }
    })

    /**
     *  Click event handler for close button in modal window
     */
    $('body').on('click keypress', '.closeModal', function ($e) {
        $('#overlay').remove();
    })


    /**
     *  Click event handler for 'System Name' column link
     */
    $('body').on('click keypress', '.gotoSystemDetailBySystemNameLink', function ($e) {

        if ($e.type == 'click' || $e.which == 13) {
            var $this = $(this),
                id = $this.attr('system-id');

            cmcApp.Lib.UIComponent.gotoSystemDetailPage(id);
        }
    });

    /**
     *  Change event handler for system type (hypervisor, physical server, virtual mahcine) dropdown menu
     */
    $('body').on('change', '#selectSystemType', function ($e) {

        filterLicenseListItems();

    });

    /**
     *  Tab event handler for system type (hypervisor, physical server, virtual mahcine) dropdown menu
     */
    $('body').on('keydown', '#systemTypeSelectHolder .bootstrap-select a', function (e) {

        if (e.which == 9) { // tab
            e.preventDefault();

            var $dropdownTarget = $('.bootstrap-select').removeClass('open');
            $('[TabIndex="' + (cmcApp.LICENSE_FIRST_TAB_INDEX + 301) + '"]').focus();

            return false;
        }
    });

    /**
     *  "Rename" license link in the "Add / Rename Licenses" modal window
     */
    $('body').on('click keypress', '.renameLicenseLink', function ($e) {
        if ($e.type == 'click' || $e.which == 13) {

            var $this = $(this),
              name = $this.attr('name'),
                sn = $this.attr('sn');

            openRenameLicenseModal(sn, name);
        }
    });

    /**
     *  "Add license" link in the "Add / Rename Licenses" modal window
     */
    $('body').on('click keypress', '.addLicenseLink', function ($e) {
        if ($e.type == 'click' || $e.which == 13) {

            var $this = $(this),
              fileName = $this.attr('fileName');

            executeAddLicense(fileName);
        }
    });

    /**
     *  Change handler for license radio buttons in the "Assign License" modal window
     */
    $('body').on('change', '.licenseSelect', function ($e) {

        $('.assignBtn').removeClass('disabled').attr('disabled', false);
    });


}

//////////////////////////////////////////////////////////////////////////
//                               EVENT CONSTANTS                          //
//////////////////////////////////////////////////////////////////////////
License.GET_LICENSE_COMPLETE = "getLicenseComplete";
License.GET_LICENSE_SUMMARY_COMPLETE = "getLicenseSummaryComplete";
License.GET_LICENSED_SYSTEMS_COMPLETE = "getLicensedSystemsComplete";
License.CHECK_LICENSE_COMPLETE = "checkLicenseComplete";
License.RECLAIM_LICENSE_COMPLETE = "reclaimLicenseComplete";
License.GET_LICENSE_TYPE_COMPLETE = "getLicenseTypeComplete";
License.GET_NEW_LICENSES_COMPLETE = "getNewLicensesComplete";
License.RENAME_LICENSE_COMPLETE = "renameLicenseComplete";
License.ADD_LICENSE_COMPLETE = "addLicenseComplete";
License.ASSIGN_LICENSE_COMPLETE = "assignLicenseComplete";
License.REMOVE_LICENSE_COMPLETE = "removeLicenseComplete";
License.VALIDATE_ASSIGN_LICENSE_COMPLETE = "validateAssignLicenseComplete";

//////////////////////////////////////////////////////////////////////////
//                      LICENSE TYPE CONSTANTS                          //
//////////////////////////////////////////////////////////////////////////
License.UNLICENSED_TYPE   = "unlicensed";
License.PERPETUAL_TYPE    = "perpetual";
License.TRIAL_TYPE        = "trial";
License.SUBSCRIPTION_TYPE = "subscription";
License.MAINTENANCE_TYPE  = "maintenance";
License.UNKNOWN_TYPE      = "unknown";

License.NAME_BY_TYPE = {
    "unlicensed":   "Unlicensed",
    "perpetual":    "Site License",  //perpetual should be either volume or site
    "trial":        "Evaluation",
    "subscription": "Subscription",
    "maintenance":  "Maintenance",
    "unknown":      ""
};

License.HYPERVISOR_SYSTEM_TYPE = 1;
License.PHYSICAL_SYSTEM_TYPE = 2;
License.VIRTUAL_MACHINE_TYPE = 3;

License.SYSTEM_TYPE = {
    1: "Hypervisor",
    2: "Physical Machine",
    3: "Virtual Machine"
}

License.TRIAL_VERSION = "TrialVersion";
License.FULL_VERSION = "FullVersion";
